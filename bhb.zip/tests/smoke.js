﻿'use strict';
/* Smoke test for the BHB Market API — run with: node tests/smoke.js [baseUrl] */
const BASE = process.argv[2] || 'http://127.0.0.1:3000';
let cookie = '';
let csrf = '';

async function call(method, path, body, opts) {
  opts = opts || {};
  const headers = { 'Accept': 'application/json' };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (cookie) headers['Cookie'] = cookie;
  if (csrf && !opts.noCsrf) headers['X-CSRF-Token'] = csrf;
  const res = await fetch(BASE + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  const setCookie = res.headers.get('set-cookie');
  if (setCookie) cookie = setCookie.split(';')[0];
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch (e) { data = text; }
  return { status: res.status, data };
}

const results = [];
function check(name, cond, extra) {
  results.push({ name, ok: !!cond, extra });
  console.log((cond ? '  ✓ ' : '  ✗ ') + name + (cond ? '' : '  → ' + JSON.stringify(extra)));
}

(async function () {
  console.log('\nBHB Market — smoke test\n' + '='.repeat(50));

  let r = await call('GET', '/api/meta');
  check('GET /api/meta', r.status === 200 && r.data.company, r);

  r = await call('POST', '/api/auth/login', { username: 'admin', password: 'wrong' });
  check('login rejects bad password', r.status === 401, r.status);

  r = await call('POST', '/api/auth/login', { username: 'admin', password: 'Admin@2026' });
  check('login succeeds', r.status === 200 && r.data.csrfToken, r.status);
  csrf = r.data.csrfToken;

  r = await call('GET', '/api/auth/me');
  check('GET /api/auth/me + csrf after reload', r.status === 200 && r.data.csrfToken, r.status);

  r = await call('GET', '/api/dashboard');
  check('dashboard KPIs', r.status === 200 && typeof r.data.kpi.products === 'number', r.status);

  r = await call('GET', '/api/products?pageSize=5');
  check('products list + pagination', r.status === 200 && Array.isArray(r.data.items) && r.data.items.length === 5, r.status);

  const noCsrf = await fetch(BASE + '/api/products', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Cookie': cookie }, body: JSON.stringify({ name: 'x', ht: 1, vat: 0 }) });
  check('CSRF rejected without token', noCsrf.status === 403, noCsrf.status);

  r = await call('POST', '/api/products', { name: 'مادة اختبار', sku: 'TST-' + Date.now(), ht: 10, vat: 19, stock: 20 });
  check('create product', r.status === 200 && r.data.id, r.status);
  const productId = r.data.id;

  r = await call('POST', '/api/clients', { name: 'حريف اختبار', taxId: 'TST-' + Date.now(), phone: '12345678' });
  check('create client', r.status === 200 && r.data.id, r.status);
  const clientId = r.data.id;

  r = await call('POST', '/api/invoices', { clientId, date: new Date().toISOString().slice(0, 10), lines: [{ productId, qty: 3 }] });
  check('create invoice', r.status === 200 && /INV-/.test(r.data.number), r.status + ' ' + JSON.stringify(r.data).slice(0, 120));
  const invoice = r.data;
  check('invoice totals computed (HT 30 / VAT 5.7 / stamp)', invoice.ht === 30 && invoice.vat === 5.7 && invoice.total === 36.7, { ht: invoice.ht, vat: invoice.vat, total: invoice.total });

  r = await call('GET', '/api/products/' + productId);
  check('stock deducted on sale (20 → 17)', r.data.stock === 17, r.data.stock);

  r = await call('POST', '/api/invoices/' + invoice.id + '/pay', { amount: 10 });
  check('partial payment', r.status === 200 && r.data.status === 'partial' && r.data.paid === 10, r.data.status);

  r = await call('POST', '/api/invoices/' + invoice.id + '/pay', { amount: 26.7 });
  check('full payment closes invoice', r.status === 200 && r.data.status === 'paid', r.status);

  r = await call('POST', '/api/invoices/' + invoice.id + '/cancel', { reason: 'test' });
  check('cancel invoice', r.status === 200 && r.data.status === 'cancelled', r.status);

  r = await call('GET', '/api/products/' + productId);
  check('cancel restores stock (17 → 20)', r.data.stock === 20, r.data.stock);

  r = await call('POST', '/api/bills', { clientId, lines: [{ productId, qty: 2 }] });
  check('create bill', r.status === 200 && /BON-/.test(r.data.number), r.status);
  const bill = r.data;

  r = await call('POST', '/api/bills/' + bill.id + '/convert', {});
  check('convert bill to invoice', r.status === 200 && r.data.invoice.number, r.status);

  r = await call('GET', '/api/products/' + productId);
  check('conversion does NOT deduct stock twice (18)', r.data.stock === 18, r.data.stock);

  r = await call('POST', '/api/bills/' + bill.id + '/convert', {});
  check('double conversion blocked', r.status === 409, r.status);

  r = await call('GET', '/api/reports/sales?from=2000-01-01&to=2099-12-31');
  check('sales report', r.status === 200 && r.data.totals, r.status);

  r = await call('GET', '/api/reports/vat?from=2000-01-01&to=2099-12-31');
  check('VAT report by rate', r.status === 200 && Array.isArray(r.data.rows), r.status);

  r = await call('GET', '/api/reports/receivables');
  check('receivables report', r.status === 200 && r.data.buckets, r.status);

  r = await call('GET', '/api/reports/stock');
  check('stock report', r.status === 200 && r.data.totals, r.status);

  r = await call('GET', '/api/reports/profit?from=2000-01-01&to=2099-12-31');
  check('profit report', r.status === 200 && r.data.totals, r.status);

  r = await call('GET', '/api/users');
  check('users list (admin)', r.status === 200 && r.data.items.length >= 2, r.status);

  r = await call('GET', '/api/audit?pageSize=5');
  check('audit log populated', r.status === 200 && r.data.total > 5, r.data.total);

  r = await call('GET', '/api/settings');
  check('settings readable', r.status === 200 && r.data.company.name, r.status);

  r = await call('POST', '/api/auth/logout', {});
  check('logout', r.status === 200, r.status);

  csrf = '';
  r = await call('GET', '/api/dashboard');
  check('dashboard blocked after logout', r.status === 401, r.status);

  const failed = results.filter((x) => !x.ok);
  console.log('\n' + '='.repeat(50));
  console.log((results.length - failed.length) + '/' + results.length + ' checks passed' + (failed.length ? ' — ' + failed.length + ' FAILED' : ' — all good ✅'));
  process.exit(failed.length ? 1 : 0);
})().catch((e) => { console.error('FATAL', e); process.exit(1); });
