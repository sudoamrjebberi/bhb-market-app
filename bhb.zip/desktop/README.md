# BHB Market — نسخة سطح المكتب (Electron + Realm)

تطبيق مكتبي بواجهة إلكترونية، يعمل دون خادم ودون إنترنت، ويحفظ البيانات محلياً في قاعدة **Realm**.

## التشغيل

```bash
cd desktop
npm install          # يثبّت electron و realm (يحتاج اتصالاً بالإنترنت مرة واحدة)
npm start
```

على ويندوز، إن ظهر خطأ صلاحيات عند بدء Electron:

```bash
npm run start:nosandbox
```

## أين تُحفظ البيانات؟

| النظام | المسار |
|---|---|
| Windows | `%APPDATA%\bhb-market-desktop\bhb-market.realm` |
| macOS | `~/Library/Application Support/bhb-market-desktop/bhb-market.realm` |
| Linux | `~/.config/bhb-market-desktop/bhb-market.realm` |

## البنية

```
desktop/
├── main.js          عملية Electron الرئيسية: تشغيل الخلفية + النافذة + القوائم
├── preload.js       جسر آمن (contextIsolation)
├── store-realm.js   تنفيذ واجهة المخزن باستخدام Realm + مخطط البيانات
└── package.json
```

التطبيق **يعيد استخدام** نفس الواجهة (مجلد `../public`) ونفس منطق الأعمال
(`../lib/domain.js`) ونفس طبقة HTTP (`../lib/http-app.js`) المستخدمة في نسخة الويب.
الاختلاف الوحيد هو طبقة التخزين: `Realm` بدل ملف JSON.

إذا لم تكن حزمة `realm` مثبّتة، يعمل التطبيق تلقائياً بمخزن JSON محلي داخل مجلد
بيانات المستخدم، مع رسالة توضّح كيفية تفعيل Realm — حتى لا يتوقف العمل أبداً.

## مخطط Realm

`User, Client, Supplier, Product, Invoice, InvoiceLine, Bill, BillLine, Purchase,
Payment, AuditEntry, Counter, AppSetting` — مطابق لجداول الويب، مع نفس أسماء
الحقول حتى يعمل منطق الأعمال دون تعديل.

## التغليف للتوزيع (اختياري)

```bash
npm install --save-dev electron-builder
npx electron-builder --win nsis
```
