'use strict';
/** Minimal, safe bridge: the desktop UI is the same web UI, so no Node APIs are exposed. */
const { contextBridge } = require('electron');

contextBridge.exposeInMainWorld('desktop', {
  isDesktop: true,
  versions: {
    electron: process.versions.electron,
    chrome: process.versions.chrome,
    node: process.versions.node
  }
});
