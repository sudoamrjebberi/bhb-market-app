'use strict';
/**
 * desktop/store-realm.js
 * Realm implementation of the store interface used by lib/domain.js.
 * If the `realm` package is not installed (e.g. offline machine), the desktop
 * app transparently falls back to the JSON store so it always opens.
 */
const path = require('path');
const fs = require('fs');

const MAP = {
  users: 'User', clients: 'Client', suppliers: 'Supplier', products: 'Product',
  invoices: 'Invoice', invoice_lines: 'InvoiceLine', bills: 'Bill', bill_lines: 'BillLine',
  purchases: 'Purchase', payments: 'Payment', audit: 'AuditEntry'
};

const NUM = 'double';

const SCHEMA = [
  {
    name: 'User', primaryKey: 'id', properties: {
      id: 'int', username: 'string', name: 'string', role: 'string', active: 'bool',
      password: 'string', mustChangePassword: 'bool', createdAt: 'string'
    }
  },
  {
    name: 'Client', primaryKey: 'id', properties: {
      id: 'int', name: 'string', taxId: 'string?', address: 'string?', phone: 'string?',
      mobile: 'string?', fax: 'string?', email: 'string?', rc: 'string?', notes: 'string?',
      creditLimit: { type: NUM, default: 0 }, createdAt: 'string?'
    }
  },
  {
    name: 'Supplier', primaryKey: 'id', properties: {
      id: 'int', name: 'string', address: 'string?', phone: 'string?', taxId: 'string?',
      rc: 'string?', email: 'string?', createdAt: 'string?'
    }
  },
  {
    name: 'Product', primaryKey: 'id', properties: {
      id: 'int', name: 'string', sku: 'string?', ht: NUM, vat: NUM, ttc: NUM, stock: NUM,
      unit: 'string?', supplierId: 'int?', state: 'string?', minStock: { type: NUM, default: 5 },
      createdAt: 'string?'
    }
  },
  {
    name: 'Invoice', primaryKey: 'id', properties: {
      id: 'int', number: 'string', clientId: 'int?', date: 'string', ht: NUM, discount: NUM,
      vat: NUM, stamp: NUM, ttc: NUM, total: NUM, paid: { type: NUM, default: 0 },
      status: 'string', notes: 'string?', createdBy: 'int?', createdAt: 'string?',
      cancelledAt: 'string?', cancelReason: 'string?'
    }
  },
  {
    name: 'InvoiceLine', primaryKey: 'id', properties: {
      id: 'int', invoiceId: 'int?', productId: 'int?', name: 'string?', sku: 'string?',
      qty: NUM, unitHt: NUM, discountPct: { type: NUM, default: 0 }, vatRate: NUM,
      ht: NUM, discount: NUM, vat: NUM, ttc: NUM
    }
  },
  {
    name: 'Bill', primaryKey: 'id', properties: {
      id: 'int', number: 'string', clientId: 'int?', date: 'string', total: NUM,
      status: 'string', convertedInvoiceId: 'int?', notes: 'string?', createdBy: 'int?',
      createdAt: 'string?', paidAt: 'string?', cancelledAt: 'string?', convertedAt: 'string?'
    }
  },
  {
    name: 'BillLine', primaryKey: 'id', properties: {
      id: 'int', billId: 'int?', productId: 'int?', name: 'string?', qty: NUM,
      unitTtc: NUM, total: NUM
    }
  },
  {
    name: 'Purchase', primaryKey: 'id', properties: {
      id: 'int', productId: 'int?', supplierId: 'int?', qty: NUM, unitPrice: NUM, total: NUM,
      date: 'string', invoiceRef: 'string?', notes: 'string?', createdAt: 'string?', createdBy: 'int?'
    }
  },
  {
    name: 'Payment', primaryKey: 'id', properties: {
      id: 'int', invoiceId: 'int?', amount: NUM, date: 'string', method: 'string',
      note: 'string?', userId: 'int?', createdAt: 'string?'
    }
  },
  {
    name: 'AuditEntry', primaryKey: 'id', properties: {
      id: 'int', at: 'string', userId: 'int?', username: 'string?', action: 'string',
      entity: 'string?', entityId: 'int?', details: 'string?'
    }
  },
  { name: 'Counter', primaryKey: 'key', properties: { key: 'string', value: 'int' } },
  { name: 'AppSetting', primaryKey: 'key', properties: { key: 'string', json: 'string' } }
];

class RealmStore {
  constructor(realm, file) {
    this.realm = realm;
    this.file = file;
    this._writing = false;
    this._counters = {};
    this._loadCounters();
  }

  static async open(file) {
    const Realm = require('realm');
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const realm = await Realm.open({ path: file, schema: SCHEMA, schemaVersion: 1 });
    return new RealmStore(realm, file);
  }

  _loadCounters() {
    this.realm.objects('Counter').forEach((c) => { this._counters[c.key] = c.value; });
  }

  _maxId(objName) {
    const objs = this.realm.objects(objName);
    return objs.length ? objs.max('id') || 0 : 0;
  }

  _plain(obj) {
    if (!obj) return null;
    const out = {};
    for (const k of Object.keys(obj)) {
      const v = obj[k];
      out[k] = (v && typeof v === 'object' && typeof v.toJSON === 'function') ? v.toJSON() : v;
    }
    return out;
  }

  // ---- table API ---------------------------------------------------------
  all(name) {
    return Array.from(this.realm.objects(MAP[name])).map((o) => this._plain(o));
  }

  findById(name, id) {
    const obj = this.realm.objectForPrimaryKey(MAP[name], Number(id));
    return obj ? this._plain(obj) : null;
  }

  find(name, pred) { return this.all(name).filter(pred); }
  one(name, pred) { return this.all(name).find(pred) || null; }

  insert(name, row) {
    const objName = MAP[name];
    const record = Object.assign({}, row);
    if (record.id === undefined || record.id === null) record.id = this._maxId(objName) + 1;
    this._write(() => { this.realm.create(objName, record, 'modified'); });
    return Object.assign({}, record);
  }

  update(name, id, patch) {
    const objName = MAP[name];
    const obj = this.realm.objectForPrimaryKey(objName, Number(id));
    if (!obj) return null;
    this._write(() => {
      Object.keys(patch).forEach((k) => { obj[k] = patch[k]; });
    });
    return this._plain(obj);
  }

  remove(name, id) {
    const obj = this.realm.objectForPrimaryKey(MAP[name], Number(id));
    if (!obj) return false;
    this._write(() => { this.realm.delete(obj); });
    return true;
  }

  removeWhere(name, pred) {
    const doomed = Array.from(this.realm.objects(MAP[name])).filter((o) => pred(this._plain(o)));
    this._write(() => { this.realm.delete(doomed); });
    return doomed.length;
  }

  // ---- document numbers --------------------------------------------------
  nextNumber(kind, year) {
    const key = kind + ':' + year;
    let value = (this._counters[key] || 0) + 1;
    this._write(() => {
      this.realm.create('Counter', { key: key, value: value }, 'modified');
      this._counters[key] = value;
    });
    return value;
  }

  peekNumber(kind, year) { return (this._counters[kind + ':' + year] || 0) + 1; }

  // ---- settings ----------------------------------------------------------
  settings() {
    const row = this.realm.objectForPrimaryKey('AppSetting', 'app');
    if (!row) return {};
    try { return JSON.parse(row.json); } catch (e) { return {}; }
  }

  saveSettings(patch) {
    const current = this.settings();
    const next = Object.assign({}, current, patch);
    this._write(() => {
      this.realm.create('AppSetting', { key: 'app', json: JSON.stringify(next) }, 'modified');
    });
    return next;
  }

  // ---- transactions ------------------------------------------------------
  _write(fn) {
    if (this._writing || this.realm.isInTransaction) return fn();
    this._writing = true;
    try {
      this.realm.write(() => fn());
    } finally {
      this._writing = false;
    }
  }

  tx(fn) {
    if (this._writing || this.realm.isInTransaction) return fn();
    this._writing = true;
    try {
      return this.realm.write(() => fn());
    } finally {
      this._writing = false;
    }
  }

  flush() { /* Realm persists immediately */ }

  counts() {
    const out = {};
    Object.keys(MAP).forEach((name) => { out[name] = this.realm.objects(MAP[name]).length; });
    return out;
  }

  /** Bulk replace used by the SQL importer (desktop). */
  replaceTables(tables, seq) {
    this.realm.write(() => {
      Object.keys(MAP).forEach((name) => {
        const objs = this.realm.objects(MAP[name]);
        if (objs.length) this.realm.delete(objs);
      });
      this.realm.objects('Counter').forEach((c) => this.realm.delete(c));
      Object.keys(tables).forEach((name) => {
        const objName = MAP[name];
        if (!objName) return;
        tables[name].forEach((row) => {
          try { this.realm.create(objName, row, 'modified'); } catch (e) { /* skip invalid row */ }
        });
      });
      Object.keys(seq || {}).forEach((k) => {
        this.realm.create('Counter', { key: k, value: seq[k] }, 'modified');
      });
    });
    this._loadCounters();
    return this;
  }

  exportAll() {
    const tables = {};
    Object.keys(MAP).forEach((name) => { tables[name] = this.all(name); });
    return { seq: Object.assign({}, this._counters), tables: tables, settings: this.settings() };
  }

  close() { this.realm.close(); }
}

/** Open a Realm store, or fall back to the JSON store when realm is unavailable. */
async function openDesktopStore(userDataDir) {
  const file = path.join(userDataDir, 'bhb-market.realm');
  try {
    const store = await RealmStore.open(file);
    return { store, backend: 'realm', file };
  } catch (err) {
    console.warn('[realm] unavailable, falling back to JSON store:', err.message);
    const { JsonStore } = require('../lib/store-json');
    const jsonFile = path.join(userDataDir, 'db.json');
    const store = new JsonStore(jsonFile).init();
    return { store, backend: 'json', file: jsonFile, realmError: err.message };
  }
}

module.exports = { RealmStore, openDesktopStore, SCHEMA };
