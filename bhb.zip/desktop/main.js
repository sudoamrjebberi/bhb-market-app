'use strict';
/**
 * BHB Market — Desktop (Electron + Realm)
 * The desktop app starts the very same HTML/JS UI and the same business layer
 * (lib/domain.js) as the web app, but persists data in a local Realm database
 * inside the OS user-data folder. No network and no external server needed.
 */
const { app, BrowserWindow, Menu, shell, dialog } = require('electron');
const path = require('path');
const { openDesktopStore } = require('./store-realm');
const { createApi } = require('../lib/domain');
const { createApp } = require('../lib/http-app');

let mainWindow = null;
let server = null;
let backendInfo = { backend: 'unknown' };

async function startBackend() {
  const userData = app.getPath('userData');
  const opened = await openDesktopStore(userData);
  backendInfo = { backend: opened.backend, file: opened.file, error: opened.realmError };

  const api = createApi(opened.store);
  api.seed();

  const srv = createApp(opened.store);
  await new Promise((resolve, reject) => {
    srv.once('error', reject);
    srv.listen(0, '127.0.0.1', resolve);
  });
  server = srv;
  return 'http://127.0.0.1:' + srv.address().port;
}

function buildMenu() {
  const template = [
    {
      label: 'ملف',
      submenu: [
        {
          label: 'نسخة احتياطية…',
          click: async () => {
            const { canceled, filePath } = await dialog.showSaveDialog(mainWindow, {
              title: 'حفظ نسخة احتياطية',
              defaultPath: 'bhb-market-backup-' + new Date().toISOString().slice(0, 10) + '.json',
              filters: [{ name: 'JSON', extensions: ['json'] }]
            });
            if (canceled || !filePath) return;
            try {
              const res = await fetch(baseUrl + '/api/backup').catch(() => null);
              const fs = require('fs');
              if (res && res.ok) {
                fs.writeFileSync(filePath, await res.text(), 'utf8');
                dialog.showMessageBox(mainWindow, { type: 'info', message: 'تم حفظ النسخة الاحتياطية', detail: filePath });
              } else {
                dialog.showMessageBox(mainWindow, { type: 'warning', message: 'يجب تسجيل الدخول أولاً' });
              }
            } catch (e) {
              dialog.showErrorBox('تعذّر النسخ', e.message);
            }
          }
        },
        { type: 'separator' },
        { role: 'quit', label: 'خروج' }
      ]
    },
    {
      label: 'عرض',
      submenu: [
        { role: 'reload', label: 'إعادة تحميل' },
        { role: 'toggleDevTools', label: 'أدوات المطوّر' },
        { type: 'separator' },
        { role: 'resetZoom', label: 'الحجم الطبيعي' },
        { role: 'zoomIn', label: 'تكبير' },
        { role: 'zoomOut', label: 'تصغير' },
        { type: 'separator' },
        { role: 'togglefullscreen', label: 'ملء الشاشة' }
      ]
    },
    {
      label: 'مساعدة',
      submenu: [
        {
          label: 'حول التطبيق',
          click: () => dialog.showMessageBox(mainWindow, {
            type: 'info',
            message: 'BHB Market — بوحلوان إخوان',
            detail: 'الإصدار 1.0.0\nقاعدة البيانات: ' + backendInfo.backend.toUpperCase() +
              '\n' + backendInfo.file + '\n\nElectron ' + process.versions.electron + ' — Chromium ' + process.versions.chrome
          })
        }
      ]
    }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

let baseUrl = '';

async function createWindow() {
  baseUrl = await startBackend();

  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1024,
    minHeight: 680,
    backgroundColor: '#f5f8f9',
    title: 'بوحلوان إخوان — GestCom',
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });

  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.on('closed', () => { mainWindow = null; });

  // external links open in the system browser, never inside the app
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (!url.startsWith(baseUrl)) { shell.openExternal(url); return { action: 'deny' }; }
    return { action: 'allow' };
  });

  await mainWindow.loadURL(baseUrl);
  buildMenu();

  if (backendInfo.backend !== 'realm') {
    dialog.showMessageBox(mainWindow, {
      type: 'warning',
      message: 'تم تشغيل النسخة المكتبية بمخزن JSON',
      detail: 'حزمة Realm غير مثبّتة على هذا الجهاز، لذلك يعمل التطبيق بمخزن JSON محلي مؤقت.\n' +
        'لتفعيل قاعدة بيانات Realm: افتح مجلد desktop ثم نفّذ:\n\n    npm install\n    npm start\n\n' +
        'تفاصيل الخطأ: ' + (backendInfo.error || '—')
    });
  }
}

app.whenReady().then(createWindow).catch((err) => {
  dialog.showErrorBox('تعذّر تشغيل التطبيق', String(err && err.stack || err));
  app.quit();
});

app.on('window-all-closed', () => {
  if (server) { try { server.close(); } catch (e) { /* ignore */ } }
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
