/* BHB Market — front-end (vanilla JS, no dependencies) */
(function () {
  'use strict';

  const state = { user: null, permissions: [], meta: null, csrf: null, route: '', nav: [] };

  // ---------------------------------------------------------------- helpers
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
  const icon = (name, cls) => '<svg viewBox="0 0 24 24" class="' + (cls || '') + '"><use href="#' + name + '"/></svg>';
  const esc = (v) => String(v === undefined || v === null ? '' : v)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  const num = (n, d) => Number(n || 0).toLocaleString('fr-FR', { minimumFractionDigits: d === undefined ? 3 : d, maximumFractionDigits: d === undefined ? 3 : d });
  const money = (n) => num(n, 3) + ' <small>د.ت</small>';
  const dt = (s) => s ? String(s).slice(8, 10) + '/' + String(s).slice(5, 7) + '/' + String(s).slice(0, 4) : '—';
  const todayStr = () => new Date().toISOString().slice(0, 10);
  const can = (perm) => state.permissions.indexOf(perm) !== -1;

  function toast(message, type) {
    const root = $('#toast-root');
    const el = document.createElement('div');
    el.className = 'toast ' + (type || '');
    el.innerHTML = icon(type === 'error' ? 'i-alert' : type === 'warn' ? 'i-alert' : 'i-check') + '<div>' + esc(message) + '</div>';
    root.appendChild(el);
    setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateX(12px)'; setTimeout(() => el.remove(), 250); }, 3600);
  }

  // ---------------------------------------------------------------- api
  async function api(path, options) {
    options = options || {};
    const headers = { 'Accept': 'application/json' };
    if (options.body !== undefined) headers['Content-Type'] = 'application/json';
    if (state.csrf && options.method && options.method !== 'GET') headers['X-CSRF-Token'] = state.csrf;
    const res = await fetch(path, {
      method: options.method || 'GET',
      headers: headers,
      credentials: 'same-origin',
      body: options.body !== undefined ? JSON.stringify(options.body) : undefined
    });
    let data = null;
    try { data = await res.json(); } catch (e) { data = null; }
    if (res.status === 401 && path !== '/api/auth/login') { showLogin(); throw new Error('انتهت الجلسة'); }
    if (!res.ok) throw new Error((data && data.error) || 'تعذّر تنفيذ العملية (' + res.status + ')');
    return data;
  }

  // ---------------------------------------------------------------- modal
  function openModal(opts) {
    const root = $('#modal-root');
    const wrap = document.createElement('div');
    wrap.className = 'modal open';
    wrap.innerHTML =
      '<div class="modal-card ' + (opts.wide ? 'wide' : '') + '" role="dialog" aria-modal="true">' +
        '<div class="modal-head"><h3>' + esc(opts.title) + '</h3><div class="spacer"></div>' +
          '<button class="icon-btn" data-close aria-label="إغلاق">' + icon('i-x') + '</button></div>' +
        '<div class="modal-body">' + opts.body + '</div>' +
        '<div class="modal-foot">' + (opts.footer || '') + '</div>' +
      '</div>';
    root.appendChild(wrap);
    const close = () => wrap.remove();
    wrap.addEventListener('click', (e) => { if (e.target === wrap || e.target.closest('[data-close]')) close(); });
    document.addEventListener('keydown', function onEsc(e) { if (e.key === 'Escape') { close(); document.removeEventListener('keydown', onEsc); } });
    if (opts.onOpen) opts.onOpen(wrap, close);
    return { wrap, close };
  }

  function confirmDialog(title, message, confirmLabel) {
    return new Promise((resolve) => {
      const m = openModal({
        title: title,
        body: '<p style="font-size:14px;color:var(--text-2);line-height:1.8">' + esc(message) + '</p>',
        footer: '<button class="btn btn-danger" data-yes>' + icon('i-check') + ' ' + esc(confirmLabel || 'تأكيد') + '</button>' +
                '<button class="btn btn-ghost" data-close>إلغاء</button>',
        onOpen: (wrap, close) => {
          wrap.querySelector('[data-yes]').addEventListener('click', () => { close(); resolve(true); });
          wrap.addEventListener('click', (e) => { if (e.target === wrap || e.target.closest('[data-close]')) resolve(false); });
        }
      });
      m.wrap.addEventListener('click', (e) => { if (e.target === m.wrap) resolve(false); });
    });
  }

  // ---------------------------------------------------------------- forms
  function fieldHtml(f, value) {
    const v = value === undefined || value === null ? '' : value;
    const common = 'id="f-' + f.name + '" name="' + f.name + '"';
    let control;
    if (f.type === 'select') {
      control = '<select ' + common + '>' + (f.options || []).map(function (o) {
        return '<option value="' + esc(o.value) + '"' + (String(o.value) === String(v) ? ' selected' : '') + '>' + esc(o.label) + '</option>';
      }).join('') + '</select>';
    } else if (f.type === 'textarea') {
      control = '<textarea ' + common + ' rows="' + (f.rows || 3) + '" placeholder="' + esc(f.placeholder || '') + '">' + esc(v) + '</textarea>';
    } else if (f.type === 'checkbox') {
      control = '<label class="switch"><input type="checkbox" ' + common + (v ? ' checked' : '') + '> ' + esc(f.label) + '</label>';
      return '<div class="field ' + (f.full ? 'full' : '') + '">' + control + '</div>';
    } else {
      control = '<input ' + common + ' type="' + (f.type || 'text') + '" value="' + esc(v) + '"' +
        (f.step ? ' step="' + f.step + '"' : '') + (f.min !== undefined ? ' min="' + f.min + '"' : '') +
        (f.max !== undefined ? ' max="' + f.max + '"' : '') +
        ' placeholder="' + esc(f.placeholder || '') + '"' + (f.required ? ' required' : '') + '>';
    }
    return '<label class="field ' + (f.full ? 'full' : '') + '"><span>' + esc(f.label) + (f.required ? ' *' : '') + '</span>' +
      control + (f.hint ? '<small>' + esc(f.hint) + '</small>' : '') + '</label>';
  }

  function openForm(opts) {
    const body = '<form id="modal-form" class="form-grid">' + opts.fields.map(function (f) {
      return fieldHtml(f, opts.values ? opts.values[f.name] : undefined);
    }).join('') + '</form>';
    const submitLabel = opts.submitLabel || 'حفظ';
    const m = openModal({
      title: opts.title,
      wide: opts.wide,
      body: body,
      footer: '<button class="btn btn-primary" data-submit>' + icon('i-check') + ' ' + esc(submitLabel) + '</button>' +
              '<button class="btn btn-ghost" data-close>إلغاء</button>',
      onOpen: (wrap, close) => {
        const form = wrap.querySelector('#modal-form');
        const doSubmit = async () => {
          if (!form.reportValidity()) return;
          const data = {};
          opts.fields.forEach(function (f) {
            const input = form.querySelector('[name="' + f.name + '"]');
            if (!input) return;
            data[f.name] = f.type === 'checkbox' ? input.checked : input.value;
          });
          const btn = wrap.querySelector('[data-submit]');
          btn.disabled = true;
          try {
            await opts.onSubmit(data, close);
            close();
          } catch (err) {
            toast(err.message, 'error');
            btn.disabled = false;
          }
        };
        wrap.querySelector('[data-submit]').addEventListener('click', doSubmit);
        form.addEventListener('submit', (e) => { e.preventDefault(); doSubmit(); });
      }
    });
    return m;
  }

  // ---------------------------------------------------------------- layout
  function setTitle(title, sub) {
    $('#page-title').textContent = title;
    $('#page-sub').textContent = sub || '';
    document.title = title + ' — بوحلوان إخوان';
  }

  function showLogin() {
    state.user = null; state.csrf = null;
    $('#app').hidden = true;
    $('#login-screen').style.display = '';
    document.body.style.overflow = '';
  }

  function showApp() {
    $('#login-screen').style.display = 'none';
    $('#app').hidden = false;
    $('#user-name').textContent = state.user.name;
    $('#user-role').textContent = state.user.roleLabel;
    $('#user-avatar').textContent = (state.user.name || 'م').trim().charAt(0);
    const d = new Date();
    $('#today-label').textContent = d.toLocaleDateString('ar-TN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    $$('#nav a[data-perm]').forEach(function (a) { a.style.display = can(a.dataset.perm) ? '' : 'none'; });
    if (state.user.mustChangePassword) promptPasswordChange();
  }

  function promptPasswordChange() {
    openForm({
      title: 'تغيير كلمة السر الافتراضية',
      fields: [
        { name: 'currentPassword', label: 'كلمة السر الحالية', type: 'password', required: true },
        { name: 'newPassword', label: 'كلمة السر الجديدة', type: 'password', required: true, hint: '8 أحرف على الأقل مع حرف ورقم', full: true }
      ],
      submitLabel: 'تغيير كلمة السر',
      onSubmit: async (data) => {
        await api('/api/auth/password', { method: 'POST', body: data });
        state.user.mustChangePassword = false;
        toast('تم تغيير كلمة السر بنجاح');
      }
    });
  }

  // ---------------------------------------------------------------- router
  const pages = {};
  function navigate() {
    const hash = location.hash.replace(/^#\/?/, '') || 'dashboard';
    const parts = hash.split('/');
    const name = parts[0];
    state.route = hash;
    if (!state.user) return;
    $$('#nav a').forEach(function (a) { a.classList.toggle('active', a.getAttribute('href') === '#/' + name || (name === 'invoices' && a.getAttribute('href') === '#/invoices')); });
    $$('#bottom-nav a').forEach(function (a) { a.classList.toggle('on', a.getAttribute('href') === '#/' + name); });
    const page = pages[name] || pages.dashboard;
    const view = $('#view');
    view.innerHTML = '<div class="card"><div class="card-body"><div class="skeleton" style="width:40%"></div><div class="skeleton" style="margin-top:12px"></div><div class="skeleton" style="margin-top:8px;width:70%"></div></div></div>';
    Promise.resolve(page(parts.slice(1))).catch(function (err) {
      view.innerHTML = '<div class="card"><div class="card-body empty">' + icon('i-alert') + '<h4>تعذّر تحميل الصفحة</h4><p>' + esc(err.message) + '</p></div></div>';
    });
    $('#sidebar').classList.remove('open'); $('#scrim').classList.remove('show');
    view.focus({ preventScroll: true });
    window.scrollTo({ top: 0 });
  }

  // ---------------------------------------------------------------- pager
  function pager(res, onGo) {
    if (!res || res.pages <= 1) return '';
    const cur = res.page, max = res.pages;
    let buttons = '';
    const add = (n) => { buttons += '<button class="' + (n === cur ? 'on' : '') + '" data-page="' + n + '">' + n + '</button>'; };
    const range = [];
    for (let i = Math.max(1, cur - 2); i <= Math.min(max, cur + 2); i++) range.push(i);
    if (range[0] > 1) { add(1); if (range[0] > 2) buttons += '<span class="muted">…</span>'; }
    range.forEach(add);
    if (range[range.length - 1] < max) { if (range[range.length - 1] < max - 1) buttons += '<span class="muted">…</span>'; add(max); }
    return '<div class="pager"><span class="info">' + num(res.total, 0) + ' سجل — الصفحة ' + cur + ' من ' + max + '</span>' +
      '<div class="spacer"></div>' +
      '<button data-page="' + Math.max(1, cur - 1) + '"' + (cur === 1 ? ' disabled' : '') + '>›</button>' +
      buttons +
      '<button data-page="' + Math.min(max, cur + 1) + '"' + (cur === max ? ' disabled' : '') + '>‹</button></div>';
  }

  function bindPager(container, onGo) {
    $$('[data-page]', container).forEach(function (b) {
      b.addEventListener('click', function () { onGo(parseInt(b.dataset.page, 10)); });
    });
  }

  // ================================================================ PAGES
  // ---- dashboard
  pages.dashboard = async function () {
    setTitle('لوحة التحكم', 'نظرة سريعة على نشاط اليوم');
    const d = await api('/api/dashboard');
    const k = d.kpi;
    const max = Math.max.apply(null, d.series.map((s) => s.total).concat([1]));
    const bars = d.series.map(function (s) {
      const hh = Math.max(4, Math.round(s.total / max * 100));
      return '<div class="bar" title="' + num(s.total, 3) + ' د.ت"><i style="height:' + hh + '%"></i><b>' + dt(s.date).slice(0, 5) + '</b></div>';
    }).join('');

    const kpi = (cls, ic, value, label, sub) =>
      '<div class="kpi"><div class="kpi-icon ' + cls + '">' + icon(ic) + '</div><div class="kpi-meta">' +
      '<div class="kpi-value">' + value + '</div><div class="kpi-label">' + label + '</div>' +
      (sub ? '<div class="kpi-sub">' + sub + '</div>' : '') + '</div></div>';

    const rows = d.recentInvoices.map(function (i) {
      return '<tr><td><div class="t-name">' + esc(i.number) + '</div><div class="t-sub">' + dt(i.date) + '</div></td>' +
        '<td>' + esc(i.clientName) + '</td><td class="num">' + num(i.total) + '</td>' +
        '<td>' + statusBadge(i.status) + '</td></tr>';
    }).join('') || '<tr><td colspan="4"><div class="empty">لا توجد فواتير بعد</div></td></tr>';

    const lowRows = d.lowStock.map(function (p) {
      return '<tr><td><div class="t-name">' + esc(p.name) + '</div><div class="t-sub">' + esc(p.sku || '') + '</div></td>' +
        '<td class="num">' + num(p.stock, 0) + '</td><td><span class="badge ' + (p.stock <= 0 ? 'red' : 'amber') + '">' + (p.stock <= 0 ? 'نفد' : 'منخفض') + '</span></td></tr>';
    }).join('') || '<tr><td colspan="3"><div class="empty">المخزون في حالة جيدة</div></td></tr>';

    $('#view').innerHTML =
      '<div class="kpis">' +
        kpi('green', 'i-money', num(k.todaySales) + ' <small>د.ت</small>', 'مبيعات اليوم', k.todayCount + ' فاتورة') +
        kpi('blue', 'i-chart', num(k.monthSales) + ' <small>د.ت</small>', 'مبيعات الشهر', k.monthCount + ' فاتورة') +
        kpi('amber', 'i-alert', num(k.due) + ' <small>د.ت</small>', 'ذمم غير محصّلة', k.dueCount + ' مستند') +
        kpi('mint', 'i-box', num(k.products, 0), 'مادة مسجّلة', k.lowStockCount + ' تحت حد التنبيه') +
      '</div>' +
      '<div class="grid grid-2">' +
        '<div class="card"><div class="card-head"><h2>حركة المبيعات — 7 أيام</h2><div class="spacer"></div><span class="badge blue">' + num(k.stockValue) + ' د.ت مخزون</span></div>' +
          '<div class="card-body"><div class="bar-chart">' + bars + '</div><div class="chart-legend"><span>● إجمالي الفواتير اليومية</span></div></div></div>' +
        '<div class="card"><div class="card-head"><h2>مواد تحت حد التنبيه</h2><div class="spacer"></div><a class="btn btn-sm btn-soft" href="#/products">عرض الكل</a></div>' +
          '<div class="card-body tight"><div class="table-wrap"><table class="data"><thead><tr><th>المادة</th><th>المخزون</th><th>الحالة</th></tr></thead><tbody>' + lowRows + '</tbody></table></div></div></div>' +
      '</div>' +
      '<div class="grid grid-2" style="margin-top:20px">' +
        '<div class="card"><div class="card-head"><h2>أحدث الفواتير</h2><div class="spacer"></div><a class="btn btn-sm btn-soft" href="#/invoices">كل الفواتير</a></div>' +
          '<div class="card-body tight"><div class="table-wrap"><table class="data"><thead><tr><th>الفاتورة</th><th>الحريف</th><th>الجملة</th><th>الحالة</th></tr></thead><tbody>' + rows + '</tbody></table></div></div></div>' +
        '<div class="card"><div class="card-head"><h2>ذمم في انتظار التحصيل</h2><div class="spacer"></div><span class="badge amber">' + d.unpaidInvoices.length + ' فاتورة</span></div>' +
          '<div class="card-body tight"><div class="table-wrap"><table class="data"><thead><tr><th>الفاتورة</th><th>الحريف</th><th>المتبقي</th><th>التاريخ</th></tr></thead><tbody>' +
          (d.unpaidInvoices.map(function (i) {
            return '<tr><td class="t-name">' + esc(i.number) + '</td><td>' + esc(i.clientName) + '</td><td class="num">' + num(i.balance) + '</td><td>' + dt(i.date) + '</td></tr>';
          }).join('') || '<tr><td colspan="4"><div class="empty">كل الفواتير محصّلة 🎉</div></td></tr>') +
          '</tbody></table></div></div></div>' +
      '</div>';
  };

  function statusBadge(status) {
    const map = {
      unpaid: ['amber', 'غير مدفوعة'], paid: ['green', 'خالصة'], partial: ['blue', 'دفع جزئي'],
      cancelled: ['gray', 'ملغاة'], converted: ['blue', 'محوّل لفاتورة'], draft: ['gray', 'مسودة']
    };
    const s = map[status] || ['gray', status];
    return '<span class="badge ' + s[0] + '"><i class="dot"></i>' + esc(s[1]) + '</span>';
  }

  // ---- products
  pages.products = async function () {
    setTitle('المواد', 'إدارة الأصناف والأسعار والمخزون');
    let query = { page: 1, q: '', state: '' };
    const view = $('#view');

    async function load() {
      const qs = new URLSearchParams({ page: query.page, pageSize: 12, q: query.q, state: query.state }).toString();
      const res = await api('/api/products?' + qs);
      view.innerHTML =
        '<div class="toolbar">' +
          '<div class="search">' + icon('i-search') + '<input id="p-q" placeholder="بحث بالاسم أو الرمز…" value="' + esc(query.q) + '"></div>' +
          '<div class="select-wrap"><select id="p-state">' +
            ['', 'low', 'out', 'declared', 'undeclared'].map(function (v) {
              const labels = { '': 'كل المواد', low: 'تحت الحد', out: 'نفدت', declared: 'مصرّح بها', undeclared: 'غير مصرّح بها' };
              return '<option value="' + v + '"' + (v === query.state ? ' selected' : '') + '>' + labels[v] + '</option>';
            }).join('') +
          '</select></div><div class="spacer"></div>' +
          (can('products.write') ? '<button class="btn btn-primary" id="p-add">' + icon('i-plus') + ' مادة جديدة</button>' : '') +
        '</div>' +
        '<div class="card"><div class="table-wrap"><table class="data"><thead><tr>' +
          '<th>المادة</th><th>السعر خ.أ</th><th>الأداء</th><th>السعر الجملي</th><th>المخزون</th><th>المزود</th><th></th>' +
        '</tr></thead><tbody>' +
          (res.items.map(productRow).join('') || '<tr><td colspan="7"><div class="empty">' + icon('i-box') + '<h4>لا توجد مواد</h4><p>أضف أول مادة للبدء</p></div></td></tr>') +
        '</tbody></table></div>' + pager(res) + '</div>';

      $('#p-q').addEventListener('input', debounce(function (e) { query.q = e.target.value; query.page = 1; load(); }, 280));
      $('#p-state').addEventListener('change', function (e) { query.state = e.target.value; query.page = 1; load(); });
      bindPager(view, function (p) { query.page = p; load(); });
      if ($('#p-add')) $('#p-add').addEventListener('click', () => productForm(null, load));
      $$('[data-edit]', view).forEach(function (b) { b.addEventListener('click', () => productForm(b.dataset.edit, load)); });
      $$('[data-del]', view).forEach(function (b) { b.addEventListener('click', () => deleteProduct(b.dataset.del, load)); });
    }

    function productRow(p) {
      const stockCls = p.stock <= 0 ? 'red' : (p.stock <= (p.minStock || 5) ? 'amber' : 'green');
      return '<tr><td><div class="t-name">' + esc(p.name) + '</div><div class="t-sub">' + esc(p.sku || '—') + ' · ' + esc(p.unit || '') + '</div></td>' +
        '<td class="num">' + num(p.ht) + '</td><td>' + num(p.vat, 0) + '%</td><td class="num">' + num(p.ttc) + '</td>' +
        '<td><span class="badge ' + stockCls + '">' + num(p.stock, 0) + '</span></td>' +
        '<td class="t-sub">' + esc(p.supplierName || '—') + '</td>' +
        '<td><div class="actions">' +
          (can('products.write') ? '<button class="icon-btn" data-edit="' + p.id + '" title="تعديل">' + icon('i-edit') + '</button>' +
            '<button class="icon-btn" data-del="' + p.id + '" title="حذف">' + icon('i-trash') + '</button>' : '') +
        '</div></td></tr>';
    }

    async function productForm(id, done) {
      let p = { name: '', sku: '', ht: '', vat: 7, stock: 0, unit: 'وحدة', minStock: 5, state: 'declared', supplierId: '' };
      let suppliers = { items: [] };
      try { suppliers = await api('/api/suppliers?pageSize=100'); } catch (e) { /* ignore */ }
      if (id) p = await api('/api/products/' + id);
      openForm({
        title: id ? 'تعديل مادة' : 'مادة جديدة',
        wide: true,
        values: p,
        fields: [
          { name: 'name', label: 'اسم المادة', required: true, full: true },
          { name: 'sku', label: 'الرمز / الباركود' },
          { name: 'unit', label: 'وحدة القياس' },
          { name: 'ht', label: 'السعر خالي من الأداء (د.ت)', type: 'number', step: '0.001', required: true },
          { name: 'vat', label: 'نسبة الأداء', type: 'select', options: (state.meta.vatRates || [0, 7, 13, 19]).map((r) => ({ value: r, label: r + '%' })) },
          { name: 'stock', label: 'الكمية المخزنة', type: 'number', step: '0.001' },
          { name: 'minStock', label: 'حد التنبيه', type: 'number', step: '1' },
          { name: 'state', label: 'الوضع الجبائي', type: 'select', options: [{ value: 'declared', label: 'مصرّح بها' }, { value: 'undeclared', label: 'غير مصرّح بها' }] },
          { name: 'supplierId', label: 'المزود', type: 'select', options: [{ value: '', label: 'بدون مزود' }].concat(suppliers.items.map((s) => ({ value: s.id, label: s.name }))) }
        ],
        onSubmit: async function (data) {
          const payload = Object.assign({}, data, { ht: Number(data.ht), vat: Number(data.vat), stock: Number(data.stock || 0), minStock: Number(data.minStock || 0) });
          if (id) await api('/api/products/' + id, { method: 'PUT', body: payload });
          else await api('/api/products', { method: 'POST', body: payload });
          toast(id ? 'تم تحديث المادة' : 'تمت إضافة المادة');
          done();
        }
      });
    }

    async function deleteProduct(id, done) {
      if (!await confirmDialog('حذف مادة', 'سيتم حذف المادة نهائياً. لا يمكن التراجع عن هذه العملية.', 'حذف')) return;
      try { await api('/api/products/' + id, { method: 'DELETE' }); toast('تم حذف المادة'); done(); }
      catch (e) { toast(e.message, 'error'); }
    }

    load();
  };

  // ---- clients
  pages.clients = async function () {
    setTitle('الحرفاء', 'بطاقات الحرفاء وأرصدتهم');
    let query = { page: 1, q: '' };
    const view = $('#view');

    async function load() {
      const res = await api('/api/clients?page=' + query.page + '&pageSize=12&q=' + encodeURIComponent(query.q));
      view.innerHTML =
        '<div class="toolbar"><div class="search">' + icon('i-search') + '<input id="c-q" placeholder="بحث بالاسم أو المعرف الجبائي…" value="' + esc(query.q) + '"></div>' +
        '<div class="spacer"></div>' +
        (can('clients.write') ? '<button class="btn btn-primary" id="c-add">' + icon('i-plus') + ' حريف جديد</button>' : '') + '</div>' +
        '<div class="card"><div class="table-wrap"><table class="data"><thead><tr><th>الحريف</th><th>المعرف الجبائي</th><th>الهاتف</th><th>الفواتير</th><th>الرصيد المستحق</th><th></th></tr></thead><tbody>' +
        (res.items.map(function (c) {
          return '<tr><td><div class="t-name">' + esc(c.name) + '</div><div class="t-sub">' + esc(c.address || '') + '</div></td>' +
            '<td class="t-sub">' + esc(c.taxId || '—') + '</td><td>' + esc(c.phone || '—') + '</td>' +
            '<td class="num">' + num(c.invoices, 0) + '</td>' +
            '<td>' + (c.due > 0 ? '<span class="badge amber">' + num(c.due) + ' د.ت</span>' : '<span class="badge green">0.000</span>') + '</td>' +
            '<td><div class="actions"><button class="icon-btn" data-view="' + c.id + '" title="كشف الحساب">' + icon('i-file') + '</button>' +
            (can('clients.write') ? '<button class="icon-btn" data-edit="' + c.id + '" title="تعديل">' + icon('i-edit') + '</button>' +
              '<button class="icon-btn" data-del="' + c.id + '" title="حذف">' + icon('i-trash') + '</button>' : '') + '</div></td></tr>';
        }).join('') || '<tr><td colspan="6"><div class="empty">' + icon('i-users') + '<h4>لا يوجد حرفاء</h4></div></td></tr>') +
        '</tbody></table></div>' + pager(res) + '</div>';

      $('#c-q').addEventListener('input', debounce(function (e) { query.q = e.target.value; query.page = 1; load(); }, 280));
      bindPager(view, (p) => { query.page = p; load(); });
      if ($('#c-add')) $('#c-add').addEventListener('click', () => clientForm(null, load));
      $$('[data-edit]', view).forEach((b) => b.addEventListener('click', () => clientForm(b.dataset.edit, load)));
      $$('[data-del]', view).forEach((b) => b.addEventListener('click', () => removeClient(b.dataset.del, load)));
      $$('[data-view]', view).forEach((b) => b.addEventListener('click', () => clientStatement(b.dataset.view)));
    }

    async function clientForm(id, done) {
      let c = { name: '', taxId: '', address: '', phone: '', mobile: '', fax: '', email: '', rc: '', notes: '', creditLimit: 0 };
      if (id) c = await api('/api/clients/' + id);
      openForm({
        title: id ? 'تعديل حريف' : 'حريف جديد',
        wide: true, values: c,
        fields: [
          { name: 'name', label: 'الاسم الكامل', required: true, full: true },
          { name: 'taxId', label: 'المعرف الجبائي' },
          { name: 'rc', label: 'السجل التجاري' },
          { name: 'address', label: 'العنوان', full: true },
          { name: 'phone', label: 'الهاتف' }, { name: 'mobile', label: 'المحمول' },
          { name: 'fax', label: 'الفاكس' }, { name: 'email', label: 'البريد الإلكتروني', type: 'email' },
          { name: 'creditLimit', label: 'سقف الائتمان (د.ت)', type: 'number', step: '0.001' },
          { name: 'notes', label: 'ملاحظات', type: 'textarea', full: true }
        ],
        onSubmit: async function (data) {
          if (id) await api('/api/clients/' + id, { method: 'PUT', body: data });
          else await api('/api/clients', { method: 'POST', body: data });
          toast(id ? 'تم تحديث الحريف' : 'تمت إضافة الحريف'); done();
        }
      });
    }

    async function removeClient(id, done) {
      if (!await confirmDialog('حذف حريف', 'لا يمكن حذف حريف له فواتير أو وصولات.', 'حذف')) return;
      try { await api('/api/clients/' + id, { method: 'DELETE' }); toast('تم الحذف'); done(); }
      catch (e) { toast(e.message, 'error'); }
    }

    async function clientStatement(id) {
      const c = await api('/api/clients/' + id);
      openModal({
        title: 'كشف حساب — ' + c.name,
        wide: true,
        body: '<div class="stat-row"><div class="stat"><span>عدد الفواتير</span><strong>' + num(c.invoices, 0) + '</strong></div>' +
          '<div class="stat"><span>إجمالي المبيعات</span><strong>' + num(c.total) + '</strong></div>' +
          '<div class="stat"><span>المستحق</span><strong>' + num(c.due) + '</strong></div></div>' +
          '<div class="table-wrap"><table class="data"><thead><tr><th>الفاتورة</th><th>التاريخ</th><th>الجملة</th><th>المدفوع</th><th>الحالة</th></tr></thead><tbody>' +
          (c.invoiceList.map(function (i) {
            return '<tr><td class="t-name">' + esc(i.number) + '</td><td>' + dt(i.date) + '</td><td class="num">' + num(i.total) + '</td>' +
              '<td class="num">' + num(i.paid) + '</td><td>' + statusBadge(i.status) + '</td></tr>';
          }).join('') || '<tr><td colspan="5"><div class="empty">لا توجد فواتير</div></td></tr>') +
          '</tbody></table></div>',
        footer: '<button class="btn btn-ghost" data-close>إغلاق</button>'
      });
    }

    load();
  };

  // ---- suppliers
  pages.suppliers = async function () {
    setTitle('المزودون', 'الموردون وعمليات الشراء');
    let query = { page: 1, q: '' };
    const view = $('#view');

    async function load() {
      const res = await api('/api/suppliers?page=' + query.page + '&pageSize=12&q=' + encodeURIComponent(query.q));
      view.innerHTML = '<div class="toolbar"><div class="search">' + icon('i-search') + '<input id="s-q" placeholder="بحث عن مزود…" value="' + esc(query.q) + '"></div><div class="spacer"></div>' +
        (can('suppliers.write') ? '<button class="btn btn-primary" id="s-add">' + icon('i-plus') + ' مزود جديد</button>' : '') + '</div>' +
        '<div class="card"><div class="table-wrap"><table class="data"><thead><tr><th>المزود</th><th>الهاتف</th><th>المعرف الجبائي</th><th>المواد</th><th>الشراءات</th><th></th></tr></thead><tbody>' +
        (res.items.map(function (s) {
          return '<tr><td><div class="t-name">' + esc(s.name) + '</div><div class="t-sub">' + esc(s.address || '') + '</div></td>' +
            '<td>' + esc(s.phone || '—') + '</td><td class="t-sub">' + esc(s.taxId || '—') + '</td>' +
            '<td class="num">' + num(s.productCount, 0) + '</td><td class="num">' + num(s.purchaseTotal) + '</td>' +
            '<td><div class="actions">' + (can('suppliers.write') ?
              '<button class="icon-btn" data-edit="' + s.id + '">' + icon('i-edit') + '</button>' +
              '<button class="icon-btn" data-del="' + s.id + '">' + icon('i-trash') + '</button>' : '') + '</div></td></tr>';
        }).join('') || '<tr><td colspan="6"><div class="empty">' + icon('i-truck') + '<h4>لا يوجد مزودون</h4></div></td></tr>') +
        '</tbody></table></div>' + pager(res) + '</div>';

      $('#s-q').addEventListener('input', debounce(function (e) { query.q = e.target.value; query.page = 1; load(); }, 280));
      bindPager(view, (p) => { query.page = p; load(); });
      if ($('#s-add')) $('#s-add').addEventListener('click', () => supplierForm(null, load));
      $$('[data-edit]', view).forEach((b) => b.addEventListener('click', () => supplierForm(b.dataset.edit, load)));
      $$('[data-del]', view).forEach((b) => b.addEventListener('click', async function () {
        if (!await confirmDialog('حذف مزود', 'لا يمكن حذف مزود مرتبط بمواد أو شراءات.', 'حذف')) return;
        try { await api('/api/suppliers/' + b.dataset.del, { method: 'DELETE' }); toast('تم الحذف'); load(); }
        catch (e) { toast(e.message, 'error'); }
      }));
    }

    async function supplierForm(id, done) {
      let s = { name: '', address: '', phone: '', taxId: '', rc: '', email: '' };
      if (id) s = await api('/api/suppliers?pageSize=500').then((r) => r.items.find((x) => String(x.id) === String(id)));
      openForm({
        title: id ? 'تعديل مزود' : 'مزود جديد', wide: true, values: s,
        fields: [
          { name: 'name', label: 'اسم المزود', required: true, full: true },
          { name: 'address', label: 'العنوان', full: true },
          { name: 'phone', label: 'الهاتف' }, { name: 'email', label: 'البريد الإلكتروني', type: 'email' },
          { name: 'taxId', label: 'المعرف الجبائي' }, { name: 'rc', label: 'السجل التجاري' }
        ],
        onSubmit: async function (data) {
          if (id) await api('/api/suppliers/' + id, { method: 'PUT', body: data });
          else await api('/api/suppliers', { method: 'POST', body: data });
          toast('تم الحفظ'); done();
        }
      });
    }
    load();
  };

  // ---- invoices list
  pages.invoices = async function () {
    setTitle('الفواتير', 'إدارة الفواتير والتحصيل');
    let query = { page: 1, q: '', status: '', from: '', to: '' };
    const view = $('#view');

    async function load() {
      const qs = new URLSearchParams({ page: query.page, pageSize: 12, q: query.q, status: query.status, from: query.from, to: query.to }).toString();
      const res = await api('/api/invoices?' + qs);
      view.innerHTML =
        '<div class="toolbar">' +
          '<div class="search">' + icon('i-search') + '<input id="i-q" placeholder="رقم الفاتورة أو الحريف…" value="' + esc(query.q) + '"></div>' +
          '<div class="select-wrap"><select id="i-status">' +
            [['', 'كل الحالات'], ['unpaid', 'غير مدفوعة'], ['partial', 'دفع جزئي'], ['paid', 'خالصة'], ['cancelled', 'ملغاة']].map(function (o) {
              return '<option value="' + o[0] + '"' + (o[0] === query.status ? ' selected' : '') + '>' + o[1] + '</option>';
            }).join('') + '</select></div>' +
          '<div class="date-range"><input type="date" id="i-from" value="' + esc(query.from) + '"><span class="muted">→</span><input type="date" id="i-to" value="' + esc(query.to) + '"></div>' +
          '<div class="spacer"></div>' +
          (can('invoices.write') ? '<a class="btn btn-primary" href="#/invoices/new">' + icon('i-plus') + ' فاتورة جديدة</a>' : '') +
        '</div>' +
        '<div class="stat-row">' +
          '<div class="stat"><span>عدد الفواتير</span><strong>' + num(res.summary.count, 0) + '</strong></div>' +
          '<div class="stat"><span>إجمالي المبيعات</span><strong>' + num(res.summary.total) + '</strong></div>' +
          '<div class="stat"><span>غير محصّل</span><strong>' + num(res.summary.due) + '</strong></div>' +
        '</div>' +
        '<div class="card"><div class="table-wrap"><table class="data"><thead><tr>' +
          '<th>الفاتورة</th><th>الحريف</th><th>التاريخ</th><th>خ.أ</th><th>الأداء</th><th>الجملة</th><th>المتبقي</th><th>الحالة</th><th></th>' +
        '</tr></thead><tbody>' +
        (res.items.map(function (i) {
          return '<tr><td><div class="t-name">' + esc(i.number) + '</div></td><td>' + esc(i.clientName) + '</td><td>' + dt(i.date) + '</td>' +
            '<td class="num">' + num(i.ht) + '</td><td class="num">' + num(i.vat) + '</td><td class="num">' + num(i.total) + '</td>' +
            '<td>' + (i.balance > 0 ? '<span class="badge amber">' + num(i.balance) + '</span>' : '<span class="badge green">0.000</span>') + '</td>' +
            '<td>' + statusBadge(i.status) + '</td>' +
            '<td><div class="actions">' +
              '<button class="icon-btn" data-open="' + i.id + '" title="عرض">' + icon('i-file') + '</button>' +
              '<button class="icon-btn" data-print="' + i.id + '" title="طباعة">' + icon('i-print') + '</button>' +
              ((i.status === 'unpaid' || i.status === 'partial') && can('invoices.pay') ? '<button class="icon-btn" data-pay="' + i.id + '" title="تحصيل">' + icon('i-money') + '</button>' : '') +
              (i.status !== 'paid' && i.status !== 'cancelled' && can('invoices.write') ? '<button class="icon-btn" data-edit="' + i.id + '" title="تعديل">' + icon('i-edit') + '</button>' : '') +
            '</div></td></tr>';
        }).join('') || '<tr><td colspan="9"><div class="empty">' + icon('i-file') + '<h4>لا توجد فواتير</h4><p>ابدأ بإنشاء فاتورة جديدة</p></div></td></tr>') +
        '</tbody></table></div>' + pager(res) + '</div>';

      $('#i-q').addEventListener('input', debounce(function (e) { query.q = e.target.value; query.page = 1; load(); }, 280));
      $('#i-status').addEventListener('change', function (e) { query.status = e.target.value; query.page = 1; load(); });
      $('#i-from').addEventListener('change', function (e) { query.from = e.target.value; query.page = 1; load(); });
      $('#i-to').addEventListener('change', function (e) { query.to = e.target.value; query.page = 1; load(); });
      bindPager(view, (p) => { query.page = p; load(); });
      $$('[data-open]', view).forEach((b) => b.addEventListener('click', () => location.hash = '#/invoices/' + b.dataset.open));
      $$('[data-print]', view).forEach((b) => b.addEventListener('click', async () => printInvoice(await api('/api/invoices/' + b.dataset.print), 'client')));
      $$('[data-pay]', view).forEach((b) => b.addEventListener('click', async () => payDialog(await api('/api/invoices/' + b.dataset.pay), load)));
      $$('[data-edit]', view).forEach((b) => b.addEventListener('click', () => location.hash = '#/invoices/' + b.dataset.edit + '/edit'));
      if ($('#v-pay')) { /* nothing */ }
    }
    load();
  };

  // ---- invoice editor

  async function invoiceEditor(id) {
    setTitle(id ? 'تعديل فاتورة' : 'فاتورة جديدة', id ? 'تعديل سطور ومجاميع الفاتورة' : 'إنشاء فاتورة بيع');
    const [clients, products] = await Promise.all([api('/api/clients?pageSize=1000'), api('/api/products?pageSize=1000')]);
    let inv = { date: state.meta.today, clientId: '', stamp: state.meta.stamp, notes: '', lines: [] };
    if (id) inv = await api('/api/invoices/' + id);
    const lines = (inv.lines || []).map(function (l) {
      return { productId: l.productId, name: l.name, qty: l.qty, unitHt: l.unitHt, discountPct: l.discountPct || 0, vatRate: l.vatRate };
    });
    const view = $('#view');

    function totals() {
      let ht = 0, disc = 0, vat = 0;
      lines.forEach(function (l) {
        const h = l.qty * l.unitHt;
        const d = h * (l.discountPct || 0) / 100;
        ht += h; disc += d; vat += (h - d) * l.vatRate / 100;
      });
      const r3 = (x) => Math.round(x * 1000) / 1000;
      return { ht: r3(ht), disc: r3(disc), vat: r3(vat), ttc: r3(ht - disc + vat), total: r3(ht - disc + vat + Number(inv.stamp || 0)) };
    }

    function render() {
      const t = totals();
      view.innerHTML =
        '<div class="card"><div class="card-body">' +
          '<div class="doc-head">' +
            '<label class="field"><span>الحريف *</span><select id="iv-client">' +
              '<option value="">— اختر حريفاً —</option>' +
              clients.items.map(function (c) { return '<option value="' + c.id + '"' + (String(c.id) === String(inv.clientId) ? ' selected' : '') + '>' + esc(c.name) + '</option>'; }).join('') +
            '</select></label>' +
            '<label class="field"><span>التاريخ</span><input type="date" id="iv-date" value="' + esc(inv.date) + '"></label>' +
            '<label class="field"><span>الطابع الجبائي</span><input type="number" step="0.001" id="iv-stamp" value="' + esc(inv.stamp) + '"></label>' +
            '<label class="field"><span>ملاحظات</span><input id="iv-notes" value="' + esc(inv.notes || '') + '" placeholder="اختياري"></label>' +
          '</div>' +
        '</div></div>' +
        '<div class="card lines-editor"><div class="card-head"><h2>أسطر الفاتورة</h2><div class="spacer"></div><span class="badge blue">' + lines.length + ' سطر</span></div>' +
          '<div class="line-add">' +
            '<label class="field"><span>المادة</span><select id="ln-product"><option value="">— اختر مادة —</option>' +
              products.items.map(function (p) {
                return '<option value="' + p.id + '" data-ht="' + p.ht + '" data-vat="' + p.vat + '" data-stock="' + p.stock + '">' + esc(p.name) + ' (' + num(p.stock, 0) + ')</option>';
              }).join('') + '</select></label>' +
            '<label class="field"><span>الكمية</span><input type="number" step="0.001" min="0.001" id="ln-qty" value="1"></label>' +
            '<label class="field"><span>السعر خ.أ</span><input type="number" step="0.001" min="0" id="ln-price" value="0"></label>' +
            '<label class="field"><span>تخفيض %</span><input type="number" step="0.01" min="0" max="100" id="ln-disc" value="0"></label>' +
            '<button class="btn btn-primary" id="ln-add">' + icon('i-plus') + ' إضافة</button>' +
          '</div>' +
          '<div class="table-wrap"><table class="data"><thead><tr><th>المادة</th><th>الكمية</th><th>السعر خ.أ</th><th>تخفيض %</th><th>المجموع خ.أ</th><th>الأداء</th><th>الجملة</th><th></th></tr></thead><tbody>' +
          (lines.map(function (l, idx) {
            const h = l.qty * l.unitHt;
            const d = h * (l.discountPct || 0) / 100;
            const v = (h - d) * l.vatRate / 100;
            return '<tr><td><div class="t-name">' + esc(l.name) + '</div><div class="t-sub">أداء ' + num(l.vatRate, 0) + '%</div></td>' +
              '<td><input type="number" step="0.001" min="0.001" data-ln="qty" data-idx="' + idx + '" value="' + l.qty + '"></td>' +
              '<td><input type="number" step="0.001" min="0" data-ln="price" data-idx="' + idx + '" value="' + l.unitHt + '"></td>' +
              '<td><input type="number" step="0.01" min="0" max="100" data-ln="disc" data-idx="' + idx + '" value="' + (l.discountPct || 0) + '"></td>' +
              '<td class="num">' + num(h) + '</td><td class="num">' + num(v) + '</td><td class="num">' + num(h - d + v) + '</td>' +
              '<td><button class="icon-btn" data-rm="' + idx + '">' + icon('i-trash') + '</button></td></tr>';
          }).join('') || '<tr><td colspan="8"><div class="empty">' + icon('i-cart') + '<h4>أضف أول سطر</h4><p>اختر مادة وأدخل الكمية</p></div></td></tr>') +
          '</tbody></table></div>' +
          '<div class="totals">' +
            '<div class="box"><span>المجموع خ.أ</span><strong>' + num(t.ht) + '</strong></div>' +
            '<div class="box"><span>التخفيض</span><strong>' + num(t.disc) + '</strong></div>' +
            '<div class="box"><span>الأداء</span><strong>' + num(t.vat) + '</strong></div>' +
            '<div class="box"><span>الطابع</span><strong>' + num(inv.stamp) + '</strong></div>' +
            '<div class="box grand"><span>الجملة</span><strong>' + num(t.total) + ' د.ت</strong></div>' +
          '</div>' +
        '</div>' +
        '<div class="toolbar" style="margin-top:18px">' +
          '<button class="btn btn-primary btn-lg" id="iv-save">' + icon('i-check') + (id ? ' حفظ التعديلات' : ' حفظ الفاتورة') + '</button>' +
          '<button class="btn btn-ghost" data-close-inline>إلغاء</button><div class="spacer"></div>' +
          (id ? '<button class="btn btn-ghost" id="iv-print">' + icon('i-print') + ' طباعة</button>' : '') +
          (id && can('invoices.cancel') ? '<button class="btn btn-danger" id="iv-cancel">' + icon('i-x') + ' إلغاء الفاتورة</button>' : '') +
        '</div>';

      $('#iv-client').addEventListener('change', (e) => { inv.clientId = e.target.value; });
      $('#iv-date').addEventListener('change', (e) => { inv.date = e.target.value; });
      $('#iv-stamp').addEventListener('change', (e) => { inv.stamp = Number(e.target.value || 0); render(); });
      $('#iv-notes').addEventListener('input', (e) => { inv.notes = e.target.value; });
      $('#ln-product').addEventListener('change', function (e) {
        const o = e.target.selectedOptions[0];
        if (o && o.dataset.ht) { $('#ln-price').value = o.dataset.ht; inv._vat = Number(o.dataset.vat); inv._stock = Number(o.dataset.stock); }
      });
      $('#ln-add').addEventListener('click', function () {
        const sel = $('#ln-product');
        const o = sel.selectedOptions[0];
        if (!sel.value) return toast('اختر مادة أولاً', 'warn');
        const qty = Number($('#ln-qty').value || 0);
        if (!(qty > 0)) return toast('الكمية يجب أن تكون أكبر من صفر', 'warn');
        const stock = Number(o.dataset.stock);
        if (!state.meta.allowNegativeStock && qty > stock && !id) toast('تنبيه: الكمية أكبر من المخزون (' + num(stock, 0) + ')', 'warn');
        lines.push({
          productId: Number(sel.value), name: o.textContent.replace(/\s*\([^)]*\)\s*$/, ''),
          qty: qty, unitHt: Number($('#ln-price').value || 0), discountPct: Number($('#ln-disc').value || 0),
          vatRate: Number(o.dataset.vat)
        });
        render();
      });
      $$('[data-rm]', view).forEach((b) => b.addEventListener('click', function () { lines.splice(Number(b.dataset.rm), 1); render(); }));
      $$('[data-ln]', view).forEach(function (input) {
        input.addEventListener('change', function () {
          const i = Number(input.dataset.idx);
          const v = Number(input.value || 0);
          if (input.dataset.ln === 'qty') lines[i].qty = Math.max(0.001, v);
          if (input.dataset.ln === 'price') lines[i].unitHt = Math.max(0, v);
          if (input.dataset.ln === 'disc') lines[i].discountPct = Math.min(100, Math.max(0, v));
          render();
        });
      });
      $('[data-close-inline]', view).addEventListener('click', () => { location.hash = id ? '#/invoices/' + id : '#/invoices'; });
      $('#iv-save').addEventListener('click', async function () {
        const btn = this; btn.disabled = true;
        try {
          if (!inv.clientId) throw new Error('اختر الحريف أولاً');
          if (!lines.length) throw new Error('أضف سطراً واحداً على الأقل');
          const payload = { clientId: inv.clientId, date: inv.date, stamp: inv.stamp, notes: inv.notes, lines: lines };
          const saved = id ? await api('/api/invoices/' + id, { method: 'PUT', body: payload }) : await api('/api/invoices', { method: 'POST', body: payload });
          toast('تم حفظ الفاتورة ' + saved.number);
          location.hash = '#/invoices/' + saved.id;
        } catch (e) { toast(e.message, 'error'); btn.disabled = false; }
      });
      if ($('#iv-print')) $('#iv-print').addEventListener('click', async () => printInvoice(await api('/api/invoices/' + id), 'client'));
      if ($('#iv-cancel')) $('#iv-cancel').addEventListener('click', async function () {
        if (!await confirmDialog('إلغاء الفاتورة', 'سيتم إلغاء الفاتورة وإرجاع كمياتها إلى المخزون. لا يمكن التراجع.', 'إلغاء الفاتورة')) return;
        try { await api('/api/invoices/' + id + '/cancel', { method: 'POST', body: { reason: 'إلغاء يدوي' } }); toast('تم إلغاء الفاتورة'); location.hash = '#/invoices/' + id; }
        catch (e) { toast(e.message, 'error'); }
      });
    }
    render();
  }

  // ---- invoice detail
  async function invoiceDetail(id) {
    setTitle('تفاصيل الفاتورة', 'عرض وتحصيل وطباعة');
    const inv = await api('/api/invoices/' + id);
    const view = $('#view');
    const lineRows = inv.lines.map(function (l) {
      return '<tr><td><div class="t-name">' + esc(l.name) + '</div><div class="t-sub">' + esc(l.sku || '') + '</div></td>' +
        '<td class="num">' + num(l.qty, 0) + '</td><td class="num">' + num(l.unitHt) + '</td><td class="num">' + num(l.ht) + '</td>' +
        '<td class="num">' + num(l.discount) + '</td><td>' + num(l.vatRate, 0) + '%</td><td class="num">' + num(l.vat) + '</td><td class="num">' + num(l.ttc) + '</td></tr>';
    }).join('');
    const payRows = (inv.payments || []).map(function (p) {
      const methods = { cash: 'نقداً', check: 'شيك', transfer: 'تحويل' };
      return '<tr><td>' + dt(p.date) + '</td><td class="num">' + num(p.amount) + '</td><td>' + esc(methods[p.method] || p.method) + '</td><td class="t-sub">' + esc(p.note || '') + '</td></tr>';
    }).join('');

    view.innerHTML =
      '<div class="toolbar">' +
        '<a class="btn btn-ghost" href="#/invoices">← الفواتير</a><div class="spacer"></div>' +
        '<button class="btn btn-soft" id="d-print-client">' + icon('i-print') + ' فاتورة الحريف</button>' +
        '<button class="btn btn-soft" id="d-print-accountant">' + icon('i-print') + ' فاتورة المحاسب</button>' +
        ((inv.status === 'unpaid' || inv.status === 'partial') && can('invoices.pay') ? '<button class="btn btn-primary" id="d-pay">' + icon('i-money') + ' تحصيل</button>' : '') +
        (inv.status !== 'paid' && inv.status !== 'cancelled' && can('invoices.write') ? '<a class="btn btn-ghost" href="#/invoices/' + inv.id + '/edit">' + icon('i-edit') + ' تعديل</a>' : '') +
      '</div>' +
      '<div class="grid grid-2">' +
        '<div class="card"><div class="card-head"><h2>معلومات الفاتورة</h2><div class="spacer"></div>' + statusBadge(inv.status) + '</div>' +
          '<div class="card-body"><div class="form-grid">' +
            '<div><span class="muted">رقم الفاتورة</span><div class="t-name">' + esc(inv.number) + '</div></div>' +
            '<div><span class="muted">التاريخ</span><div class="t-name">' + dt(inv.date) + '</div></div>' +
            '<div><span class="muted">الحريف</span><div class="t-name">' + esc(inv.clientName) + '</div></div>' +
            '<div><span class="muted">المعرف الجبائي</span><div class="t-name">' + esc(inv.client ? inv.client.taxId || '—' : '—') + '</div></div>' +
          '</div></div></div>' +
        '<div class="card"><div class="card-head"><h2>المجاميع</h2></div><div class="card-body">' +
          '<div class="totals" style="border:0;padding:0;background:none">' +
            '<div class="box"><span>خ.أ</span><strong>' + num(inv.ht) + '</strong></div>' +
            '<div class="box"><span>التخفيض</span><strong>' + num(inv.discount) + '</strong></div>' +
            '<div class="box"><span>الأداء</span><strong>' + num(inv.vat) + '</strong></div>' +
            '<div class="box"><span>الطابع</span><strong>' + num(inv.stamp) + '</strong></div>' +
            '<div class="box grand"><span>الجملة</span><strong>' + num(inv.total) + '</strong></div>' +
            '<div class="box"><span>المدفوع</span><strong>' + num(inv.paid) + '</strong></div>' +
            '<div class="box"><span>المتبقي</span><strong>' + num(inv.balance) + '</strong></div>' +
          '</div></div></div>' +
      '</div>' +
      '<div class="card"><div class="card-head"><h2>الأسطر</h2></div><div class="table-wrap"><table class="data"><thead><tr>' +
        '<th>المادة</th><th>الكمية</th><th>السعر خ.أ</th><th>المجموع خ.أ</th><th>التخفيض</th><th>الأداء</th><th>مبلغ الأداء</th><th>الجملة</th>' +
      '</tr></thead><tbody>' + lineRows + '</tbody></table></div></div>' +
      (payRows ? '<div class="card"><div class="card-head"><h2>الدفعات</h2></div><div class="table-wrap"><table class="data"><thead><tr><th>التاريخ</th><th>المبلغ</th><th>الطريقة</th><th>ملاحظة</th></tr></thead><tbody>' + payRows + '</tbody></table></div></div>' : '');

    $('#d-print-client').addEventListener('click', () => printInvoice(inv, 'client'));
    $('#d-print-accountant').addEventListener('click', () => printInvoice(inv, 'accountant'));
    if ($('#d-pay')) $('#d-pay').addEventListener('click', () => payDialog(inv, () => invoiceDetail(id)));
  }

  function payDialog(inv, done) {
    const balance = Math.round((inv.total - inv.paid) * 1000) / 1000;
    openForm({
      title: 'تحصيل ' + inv.number,
      values: { amount: balance, date: todayStr(), method: 'cash', note: '' },
      fields: [
        { name: 'amount', label: 'المبلغ (المتبقي ' + num(balance) + ')', type: 'number', step: '0.001', min: 0.001, max: balance, required: true },
        { name: 'date', label: 'تاريخ الدفع', type: 'date', required: true },
        { name: 'method', label: 'طريقة الدفع', type: 'select', options: [{ value: 'cash', label: 'نقداً' }, { value: 'check', label: 'شيك' }, { value: 'transfer', label: 'تحويل بنكي' }] },
        { name: 'note', label: 'ملاحظة', full: true }
      ],
      submitLabel: 'تسجيل الدفعة',
      onSubmit: async function (data) {
        await api('/api/invoices/' + inv.id + '/pay', { method: 'POST', body: { amount: Number(data.amount), date: data.date, method: data.method, note: data.note } });
        toast('تم تسجيل الدفعة'); done();
      }
    });
  }

  // ---- bills
  pages.bills = async function () {
    setTitle('الوصولات', 'وصولات البيع والتحويل إلى فواتير');
    let query = { page: 1, q: '', status: '' };
    const view = $('#view');
    async function load() {
      const res = await api('/api/bills?page=' + query.page + '&pageSize=12&q=' + encodeURIComponent(query.q) + '&status=' + query.status);
      view.innerHTML = '<div class="toolbar"><div class="search">' + icon('i-search') + '<input id="b-q" placeholder="رقم الوصل أو الحريف…" value="' + esc(query.q) + '"></div>' +
        '<div class="select-wrap"><select id="b-status">' + [['', 'كل الحالات'], ['unpaid', 'غير مدفوعة'], ['paid', 'خالصة'], ['converted', 'محوّلة'], ['cancelled', 'ملغاة']].map(function (o) {
          return '<option value="' + o[0] + '"' + (o[0] === query.status ? ' selected' : '') + '>' + o[1] + '</option>';
        }).join('') + '</select></div><div class="spacer"></div>' +
        (can('bills.write') ? '<a class="btn btn-primary" href="#/bills/new">' + icon('i-plus') + ' وصل جديد</a>' : '') + '</div>' +
        '<div class="card"><div class="table-wrap"><table class="data"><thead><tr><th>الوصل</th><th>الحريف</th><th>التاريخ</th><th>الجملة</th><th>الحالة</th><th></th></tr></thead><tbody>' +
        (res.items.map(function (b) {
          return '<tr><td class="t-name">' + esc(b.number) + '</td><td>' + esc(b.clientName) + '</td><td>' + dt(b.date) + '</td>' +
            '<td class="num">' + num(b.total) + '</td><td>' + statusBadge(b.status) + '</td>' +
            '<td><div class="actions">' +
              '<button class="icon-btn" data-print="' + b.id + '" title="طباعة">' + icon('i-print') + '</button>' +
              (b.status === 'unpaid' && can('bills.pay') ? '<button class="icon-btn" data-pay="' + b.id + '" title="تحصيل">' + icon('i-money') + '</button>' : '') +
              (b.status === 'unpaid' && can('bills.write') ? '<button class="icon-btn" data-convert="' + b.id + '" title="تحويل لفاتورة">' + icon('i-convert') + '</button>' : '') +
            '</div></td></tr>';
        }).join('') || '<tr><td colspan="6"><div class="empty">' + icon('i-receipt') + '<h4>لا توجد وصولات</h4></div></td></tr>') +
        '</tbody></table></div>' + pager(res) + '</div>';

      $('#b-q').addEventListener('input', debounce(function (e) { query.q = e.target.value; query.page = 1; load(); }, 280));
      $('#b-status').addEventListener('change', function (e) { query.status = e.target.value; query.page = 1; load(); });
      bindPager(view, (p) => { query.page = p; load(); });
      $$('[data-print]', view).forEach((b) => b.addEventListener('click', async () => printBill(await api('/api/bills/' + b.dataset.print))));
      $$('[data-pay]', view).forEach((b) => b.addEventListener('click', async function () {
        if (!await confirmDialog('تحصيل الوصل', 'سيتم تسجيل الوصل كخالص بكامل المبلغ.', 'تحصيل')) return;
        try { await api('/api/bills/' + b.dataset.pay + '/pay', { method: 'POST', body: {} }); toast('تم تحصيل الوصل'); load(); }
        catch (e) { toast(e.message, 'error'); }
      }));
      $$('[data-convert]', view).forEach((b) => b.addEventListener('click', async function () {
        if (!await confirmDialog('تحويل إلى فاتورة', 'سيتم إنشاء فاتورة من الوصل دون تغيير المخزون.', 'تحويل')) return;
        try { const r = await api('/api/bills/' + b.dataset.convert + '/convert', { method: 'POST', body: {} }); toast('تم إنشاء الفاتورة ' + r.invoice.number); location.hash = '#/invoices/' + r.invoice.id; }
        catch (e) { toast(e.message, 'error'); }
      }));
    }
    load();
  };

  async function billEditor() {
    setTitle('وصل جديد', 'بيع سريع بسعر جملي');
    const [clients, products] = await Promise.all([api('/api/clients?pageSize=1000'), api('/api/products?pageSize=1000')]);
    const lines = [];
    const bill = { clientId: '', date: state.meta.today };
    const view = $('#view');

    function total() { return lines.reduce((s, l) => s + l.qty * l.unitTtc, 0); }

    function render() {
      view.innerHTML = '<div class="card"><div class="card-body"><div class="doc-head">' +
        '<label class="field"><span>الحريف *</span><select id="b-client"><option value="">— اختر حريفاً —</option>' +
          clients.items.map((c) => '<option value="' + c.id + '"' + (String(c.id) === String(bill.clientId) ? ' selected' : '') + '>' + esc(c.name) + '</option>').join('') +
        '</select></label>' +
        '<label class="field"><span>التاريخ</span><input type="date" id="b-date" value="' + esc(bill.date) + '"></label>' +
        '<div class="field"><span>الجملة</span><div class="kpi-value">' + num(total()) + ' د.ت</div></div>' +
        '</div></div></div>' +
        '<div class="card"><div class="card-head"><h2>أسطر الوصل</h2></div>' +
        '<div class="line-add">' +
          '<label class="field"><span>المادة</span><select id="bl-product"><option value="">— اختر مادة —</option>' +
            products.items.map((p) => '<option value="' + p.id + '" data-ttc="' + p.ttc + '" data-stock="' + p.stock + '">' + esc(p.name) + ' (' + num(p.stock, 0) + ')</option>').join('') +
          '</select></label>' +
          '<label class="field"><span>الكمية</span><input type="number" step="0.001" min="0.001" id="bl-qty" value="1"></label>' +
          '<label class="field"><span>السعر الجملي</span><input type="number" step="0.001" min="0" id="bl-price" value="0"></label>' +
          '<div class="field"></div><button class="btn btn-primary" id="bl-add">' + icon('i-plus') + ' إضافة</button>' +
        '</div>' +
        '<div class="table-wrap"><table class="data"><thead><tr><th>المادة</th><th>الكمية</th><th>السعر الجملي</th><th>المجموع</th><th></th></tr></thead><tbody>' +
        (lines.map((l, i) => '<tr><td class="t-name">' + esc(l.name) + '</td><td class="num">' + num(l.qty, 0) + '</td><td class="num">' + num(l.unitTtc) + '</td><td class="num">' + num(l.qty * l.unitTtc) + '</td>' +
          '<td><button class="icon-btn" data-rm="' + i + '">' + icon('i-trash') + '</button></td></tr>').join('') ||
          '<tr><td colspan="5"><div class="empty">أضف سطراً للبدء</div></td></tr>') +
        '</tbody></table></div></div>' +
        '<div class="toolbar" style="margin-top:18px"><button class="btn btn-primary btn-lg" id="b-save">' + icon('i-check') + ' حفظ الوصل</button>' +
        '<a class="btn btn-ghost" href="#/bills">إلغاء</a></div>';

      $('#b-client').addEventListener('change', (e) => { bill.clientId = e.target.value; });
      $('#b-date').addEventListener('change', (e) => { bill.date = e.target.value; });
      $('#bl-product').addEventListener('change', function (e) {
        const o = e.target.selectedOptions[0];
        if (o && o.dataset.ttc) $('#bl-price').value = o.dataset.ttc;
      });
      $('#bl-add').addEventListener('click', function () {
        const sel = $('#bl-product');
        if (!sel.value) return toast('اختر مادة', 'warn');
        const o = sel.selectedOptions[0];
        const qty = Number($('#bl-qty').value || 0);
        if (!(qty > 0)) return toast('كمية غير صالحة', 'warn');
        lines.push({ productId: Number(sel.value), name: o.textContent.replace(/\s*\([^)]*\)\s*$/, ''), qty: qty, unitTtc: Number($('#bl-price').value || 0) });
        render();
      });
      $$('[data-rm]', view).forEach((b) => b.addEventListener('click', function () { lines.splice(Number(b.dataset.rm), 1); render(); }));
      $('#b-save').addEventListener('click', async function () {
        const btn = this; btn.disabled = true;
        try {
          if (!bill.clientId) throw new Error('اختر الحريف');
          if (!lines.length) throw new Error('أضف سطراً على الأقل');
          const saved = await api('/api/bills', { method: 'POST', body: { clientId: bill.clientId, date: bill.date, lines: lines } });
          toast('تم حفظ الوصل ' + saved.number);
          location.hash = '#/bills';
        } catch (e) { toast(e.message, 'error'); btn.disabled = false; }
      });
    }
    render();
  }

  // ---- purchases
  pages.purchases = async function () {
    setTitle('الشراءات', 'تسجيل المشتريات وتحديث المخزون');
    let query = { page: 1, q: '' };
    const view = $('#view');
    async function load() {
      const res = await api('/api/purchases?page=' + query.page + '&pageSize=12&q=' + encodeURIComponent(query.q));
      view.innerHTML = '<div class="toolbar"><div class="search">' + icon('i-search') + '<input id="pu-q" placeholder="بحث بالمادة أو المزود…" value="' + esc(query.q) + '"></div><div class="spacer"></div>' +
        (can('purchases.write') ? '<button class="btn btn-primary" id="pu-add">' + icon('i-plus') + ' عملية شراء</button>' : '') + '</div>' +
        '<div class="stat-row"><div class="stat"><span>عدد العمليات</span><strong>' + num(res.summary.count, 0) + '</strong></div>' +
        '<div class="stat"><span>إجمالي الشراءات</span><strong>' + num(res.summary.total) + '</strong></div></div>' +
        '<div class="card"><div class="table-wrap"><table class="data"><thead><tr><th>المادة</th><th>المزود</th><th>الكمية</th><th>سعر الوحدة</th><th>الجملة</th><th>التاريخ</th><th></th></tr></thead><tbody>' +
        (res.items.map(function (p) {
          return '<tr><td class="t-name">' + esc(p.productName) + '</td><td>' + esc(p.supplierName) + '</td><td class="num">' + num(p.qty, 0) + '</td>' +
            '<td class="num">' + num(p.unitPrice) + '</td><td class="num">' + num(p.total) + '</td><td>' + dt(p.date) + '</td>' +
            '<td><div class="actions">' + (can('purchases.write') ? '<button class="icon-btn" data-edit="' + p.id + '">' + icon('i-edit') + '</button>' +
              '<button class="icon-btn" data-del="' + p.id + '">' + icon('i-trash') + '</button>' : '') + '</div></td></tr>';
        }).join('') || '<tr><td colspan="7"><div class="empty">' + icon('i-cart') + '<h4>لا توجد عمليات شراء</h4></div></td></tr>') +
        '</tbody></table></div>' + pager(res) + '</div>';
      $('#pu-q').addEventListener('input', debounce(function (e) { query.q = e.target.value; query.page = 1; load(); }, 280));
      bindPager(view, (p) => { query.page = p; load(); });
      if ($('#pu-add')) $('#pu-add').addEventListener('click', () => purchaseForm(null, load));
      $$('[data-edit]', view).forEach((b) => b.addEventListener('click', () => purchaseForm(b.dataset.edit, load)));
      $$('[data-del]', view).forEach((b) => b.addEventListener('click', async function () {
        if (!await confirmDialog('حذف عملية شراء', 'سيتم إنقاص الكمية من المخزون. هل تريد المتابعة؟', 'حذف')) return;
        try { await api('/api/purchases/' + b.dataset.del, { method: 'DELETE' }); toast('تم الحذف'); load(); }
        catch (e) { toast(e.message, 'error'); }
      }));
    }

    async function purchaseForm(id, done) {
      const [products, suppliers] = await Promise.all([api('/api/products?pageSize=1000'), api('/api/suppliers?pageSize=1000')]);
      let p = { productId: '', supplierId: '', qty: 1, unitPrice: 0, date: todayStr(), invoiceRef: '', notes: '' };
      if (id) {
        const list = await api('/api/purchases?pageSize=1000');
        const found = list.items.find((x) => String(x.id) === String(id));
        if (found) p = Object.assign({}, found, { invoiceRef: found.invoiceRef || '' });
      }
      openForm({
        title: id ? 'تعديل عملية شراء' : 'عملية شراء جديدة', wide: true, values: p,
        fields: [
          { name: 'productId', label: 'المادة', type: 'select', required: true, options: products.items.map((x) => ({ value: x.id, label: x.name + ' (مخزون ' + num(x.stock, 0) + ')' })) },
          { name: 'supplierId', label: 'المزود', type: 'select', options: [{ value: '', label: 'بدون مزود' }].concat(suppliers.items.map((s) => ({ value: s.id, label: s.name }))) },
          { name: 'qty', label: 'الكمية', type: 'number', step: '0.001', min: 0.001, required: true },
          { name: 'unitPrice', label: 'سعر الوحدة', type: 'number', step: '0.001', min: 0, required: true },
          { name: 'date', label: 'التاريخ', type: 'date', required: true },
          { name: 'invoiceRef', label: 'مرجع فاتورة المزود' },
          { name: 'notes', label: 'ملاحظات', type: 'textarea', full: true }
        ],
        onSubmit: async function (data) {
          const payload = Object.assign({}, data, { qty: Number(data.qty), unitPrice: Number(data.unitPrice) });
          if (id) await api('/api/purchases/' + id, { method: 'PUT', body: payload });
          else await api('/api/purchases', { method: 'POST', body: payload });
          toast('تم الحفظ'); done();
        }
      });
    }
    load();
  };

  // ---- reports
  pages.reports = async function () {
    setTitle('التقارير', 'المبيعات والأداءات والذمم والمخزون');
    let tab = 'sales';
    const view = $('#view');
    const from = new Date(); from.setDate(1);
    let range = { from: from.toISOString().slice(0, 10), to: todayStr() };

    const tabsHtml = '<div class="report-tabs">' +
      [['sales', 'المبيعات'], ['vat', 'الأداءات'], ['receivables', 'الذمم'], ['stock', 'المخزون'], ['profit', 'الربحية'], ['top', 'الأكثر مبيعاً']]
        .map((t) => '<button data-tab="' + t[0] + '" class="' + (tab === t[0] ? 'on' : '') + '">' + t[1] + '</button>').join('') + '</div>';

    async function render() {
      const q = '?from=' + range.from + '&to=' + range.to;
      let body = '';
      if (tab === 'sales') {
        const d = await api('/api/reports/sales' + q + '&group=day');
        body = '<div class="stat-row">' +
          '<div class="stat"><span>عدد الفواتير</span><strong>' + num(d.totals.count, 0) + '</strong></div>' +
          '<div class="stat"><span>المبيعات خ.أ</span><strong>' + num(d.totals.ht) + '</strong></div>' +
          '<div class="stat"><span>الأداء</span><strong>' + num(d.totals.vat) + '</strong></div>' +
          '<div class="stat"><span>الطابع</span><strong>' + num(d.totals.discount) + '</strong></div>' +
          '<div class="stat"><span>الجملة</span><strong>' + num(d.totals.total) + '</strong></div>' +
          '<div class="stat"><span>المحصّل</span><strong>' + num(d.totals.paid) + '</strong></div></div>' +
          '<div class="card"><div class="card-head"><h2>المبيعات اليومية</h2></div><div class="table-wrap"><table class="data"><thead><tr><th>التاريخ</th><th>عدد الفواتير</th><th>خ.أ</th><th>الأداء</th><th>الجملة</th></tr></thead><tbody>' +
          (d.rows.map((r) => '<tr><td>' + dt(r.key) + '</td><td class="num">' + num(r.count, 0) + '</td><td class="num">' + num(r.ht) + '</td><td class="num">' + num(r.vat) + '</td><td class="num">' + num(r.total) + '</td></tr>').join('') || '<tr><td colspan="5"><div class="empty">لا توجد بيانات في هذه الفترة</div></td></tr>') +
          '</tbody></table></div></div>';
      } else if (tab === 'vat') {
        const d = await api('/api/reports/vat' + q);
        body = '<div class="stat-row"><div class="stat"><span>الوعاء الخاضع</span><strong>' + num(d.totals.base) + '</strong></div>' +
          '<div class="stat"><span>الأداء المستحق</span><strong>' + num(d.totals.vat) + '</strong></div>' +
          '<div class="stat"><span>الطابع الجبائي</span><strong>' + num(d.totals.stamp) + '</strong></div></div>' +
          '<div class="card"><div class="card-head"><h2>الأداءات حسب النسبة</h2></div><div class="table-wrap"><table class="data"><thead><tr><th>النسبة</th><th>الوعاء</th><th>مبلغ الأداء</th></tr></thead><tbody>' +
          (d.rows.map((r) => '<tr><td><span class="badge blue">' + num(r.rate, 0) + '%</span></td><td class="num">' + num(r.base) + '</td><td class="num">' + num(r.vat) + '</td></tr>').join('') || '<tr><td colspan="3"><div class="empty">لا توجد بيانات</div></td></tr>') +
          '</tbody></table></div></div>';
      } else if (tab === 'receivables') {
        const d = await api('/api/reports/receivables');
        body = '<div class="stat-row">' + ['0-30', '31-60', '61-90', '90+'].map(function (k) {
          return '<div class="stat"><span>' + k + ' يوم</span><strong>' + num(d.buckets[k]) + '</strong></div>';
        }).join('') + '<div class="stat"><span>الإجمالي</span><strong>' + num(d.total) + '</strong></div></div>' +
          '<div class="card"><div class="card-head"><h2>الفواتير غير المحصّلة</h2></div><div class="table-wrap"><table class="data"><thead><tr><th>الفاتورة</th><th>الحريف</th><th>التاريخ</th><th>العمر</th><th>المتبقي</th></tr></thead><tbody>' +
          (d.rows.map((r) => '<tr><td class="t-name">' + esc(r.number) + '</td><td>' + esc(r.clientName) + '</td><td>' + dt(r.date) + '</td><td>' + r.days + ' يوم</td><td class="num">' + num(r.balance) + '</td></tr>').join('') || '<tr><td colspan="5"><div class="empty">لا توجد ذمم</div></td></tr>') +
          '</tbody></table></div></div>';
      } else if (tab === 'stock') {
        const d = await api('/api/reports/stock');
        body = '<div class="stat-row"><div class="stat"><span>عدد المواد</span><strong>' + num(d.totals.count, 0) + '</strong></div>' +
          '<div class="stat"><span>قيمة المخزون خ.أ</span><strong>' + num(d.totals.value) + '</strong></div>' +
          '<div class="stat"><span>تحت حد التنبيه</span><strong>' + num(d.totals.low, 0) + '</strong></div></div>' +
          '<div class="card"><div class="card-head"><h2>حركة المخزون</h2></div><div class="table-wrap"><table class="data"><thead><tr><th>المادة</th><th>وارد</th><th>مُباع</th><th>الرصيد</th><th>القيمة</th><th>الحالة</th></tr></thead><tbody>' +
          d.rows.map((r) => '<tr><td class="t-name">' + esc(r.name) + '</td><td class="num">' + num(r.inQty, 0) + '</td><td class="num">' + num(r.soldQty, 0) + '</td>' +
            '<td class="num">' + num(r.stock, 0) + '</td><td class="num">' + num(r.value) + '</td><td>' +
            (r.low ? '<span class="badge amber">منخفض</span>' : '<span class="badge green">جيد</span>') + '</td></tr>').join('') +
          '</tbody></table></div></div>';
      } else if (tab === 'profit') {
        const d = await api('/api/reports/profit' + q);
        body = '<div class="stat-row"><div class="stat"><span>الإيراد خ.أ</span><strong>' + num(d.totals.revenue) + '</strong></div>' +
          '<div class="stat"><span>التكلفة التقديرية</span><strong>' + num(d.totals.cost) + '</strong></div>' +
          '<div class="stat"><span>الهامش</span><strong>' + num(d.totals.margin) + '</strong></div></div>' +
          '<div class="card"><div class="card-head"><h2>الربحية حسب المادة</h2><div class="spacer"></div><span class="badge blue">تقديري بناءً على متوسط الشراء</span></div>' +
          '<div class="table-wrap"><table class="data"><thead><tr><th>المادة</th><th>الكمية</th><th>الإيراد</th><th>متوسط التكلفة</th><th>الهامش</th><th>%</th></tr></thead><tbody>' +
          (d.rows.map((r) => '<tr><td class="t-name">' + esc(r.name) + '</td><td class="num">' + num(r.qty, 0) + '</td><td class="num">' + num(r.revenue) + '</td>' +
            '<td class="num">' + num(r.avgCost) + '</td><td class="num">' + num(r.margin) + '</td><td>' + num(r.marginPct, 1) + '%</td></tr>').join('') || '<tr><td colspan="6"><div class="empty">لا توجد بيانات</div></td></tr>') +
          '</tbody></table></div></div>';
      } else {
        const d = await api('/api/reports/top' + q);
        body = '<div class="grid grid-2">' +
          '<div class="card"><div class="card-head"><h2>أفضل الحرفاء</h2></div><div class="table-wrap"><table class="data"><thead><tr><th>الحريف</th><th>الفواتير</th><th>الإجمالي</th></tr></thead><tbody>' +
          (d.clients.map((r) => '<tr><td class="t-name">' + esc(r.name) + '</td><td class="num">' + num(r.count, 0) + '</td><td class="num">' + num(r.total) + '</td></tr>').join('') || '<tr><td colspan="3"><div class="empty">لا توجد بيانات</div></td></tr>') +
          '</tbody></table></div></div>' +
          '<div class="card"><div class="card-head"><h2>أفضل المواد</h2></div><div class="table-wrap"><table class="data"><thead><tr><th>المادة</th><th>الكمية</th><th>الإجمالي</th></tr></thead><tbody>' +
          (d.products.map((r) => '<tr><td class="t-name">' + esc(r.name) + '</td><td class="num">' + num(r.qty, 0) + '</td><td class="num">' + num(r.total) + '</td></tr>').join('') || '<tr><td colspan="3"><div class="empty">لا توجد بيانات</div></td></tr>') +
          '</tbody></table></div></div></div>';
      }

      view.innerHTML = tabsHtml +
        '<div class="toolbar"><div class="date-range"><input type="date" id="r-from" value="' + range.from + '"><span class="muted">→</span><input type="date" id="r-to" value="' + range.to + '"></div>' +
        '<button class="btn btn-soft" id="r-apply">تحديث</button><div class="spacer"></div><button class="btn btn-ghost" id="r-print">' + icon('i-print') + ' طباعة</button></div>' +
        body;

      $$('[data-tab]', view).forEach((b) => b.addEventListener('click', function () { tab = b.dataset.tab; render(); }));
      $('#r-apply').addEventListener('click', function () { range.from = $('#r-from').value; range.to = $('#r-to').value; render(); });
      $('#r-print').addEventListener('click', function () {
        const cards = $$('.card', view).map(function (c) { return c.outerHTML; }).join('');
        $('#print-root').innerHTML = '<div class="print-doc">' + companyHeader() +
          '<div class="print-title" style="text-align:right;margin:10px 0"><h1 style="font-size:16px">تقرير — ' + esc(document.title) + '</h1>' +
          '<div class="meta">الفترة: ' + dt(range.from) + ' → ' + dt(range.to) + '</div></div>' +
          cards + '</div>';
        window.print();
        setTimeout(function () { $('#print-root').innerHTML = ''; }, 800);
      });
    }
    render();
  };

  // ---- users
  pages.users = async function () {
    if (!can('users.manage')) return (location.hash = '#/dashboard');
    setTitle('المستخدمون', 'الحسابات والأدوار والصلاحيات');
    const view = $('#view');
    async function load() {
      const res = await api('/api/users');
      view.innerHTML = '<div class="toolbar"><span class="muted">' + res.items.length + ' حساب</span><div class="spacer"></div>' +
        '<button class="btn btn-primary" id="u-add">' + icon('i-plus') + ' مستخدم جديد</button></div>' +
        '<div class="card"><div class="table-wrap"><table class="data"><thead><tr><th>الاسم</th><th>اسم الدخول</th><th>الدور</th><th>الحالة</th><th></th></tr></thead><tbody>' +
        res.items.map(function (u) {
          return '<tr><td><div class="t-name">' + esc(u.name) + '</div></td><td class="t-sub">' + esc(u.username) + '</td>' +
            '<td><span class="badge blue">' + esc(u.roleLabel) + '</span></td>' +
            '<td>' + (u.active ? '<span class="badge green">نشط</span>' : '<span class="badge gray">معطّل</span>') + '</td>' +
            '<td><div class="actions"><button class="icon-btn" data-edit="' + u.id + '">' + icon('i-edit') + '</button>' +
            '<button class="icon-btn" data-del="' + u.id + '">' + icon('i-trash') + '</button></div></td></tr>';
        }).join('') + '</tbody></table></div></div>';
      $('#u-add').addEventListener('click', () => userForm(null, load));
      $$('[data-edit]', view).forEach((b) => b.addEventListener('click', () => userForm(b.dataset.edit, load)));
      $$('[data-del]', view).forEach((b) => b.addEventListener('click', async function () {
        if (!await confirmDialog('حذف مستخدم', 'لا يمكن التراجع عن الحذف.', 'حذف')) return;
        try { await api('/api/users/' + b.dataset.del, { method: 'DELETE' }); toast('تم الحذف'); load(); }
        catch (e) { toast(e.message, 'error'); }
      }));
    }
    async function userForm(id, done) {
      const roles = Object.keys(state.meta.roles).map((r) => ({ value: r, label: state.meta.roles[r] }));
      let u = { name: '', username: '', role: 'seller', active: true, password: '' };
      if (id) { const all = await api('/api/users'); u = all.items.find((x) => String(x.id) === String(id)) || u; }
      openForm({
        title: id ? 'تعديل مستخدم' : 'مستخدم جديد', values: u,
        fields: [
          { name: 'name', label: 'الاسم الكامل', required: true },
          { name: 'username', label: 'اسم الدخول', required: !id, hint: id ? 'لا يمكن تغييره' : 'حروف لاتينية صغيرة وأرقام' },
          { name: 'role', label: 'الدور', type: 'select', options: roles },
          { name: 'password', label: id ? 'كلمة سر جديدة (اختياري)' : 'كلمة السر', type: 'password', hint: '8 أحرف على الأقل مع حرف ورقم' },
          { name: 'active', label: 'الحساب نشط', type: 'checkbox', full: true }
        ],
        onSubmit: async function (data) {
          if (id) {
            const payload = { name: data.name, role: data.role, active: data.active };
            if (data.password) payload.password = data.password;
            await api('/api/users/' + id, { method: 'PUT', body: payload });
          } else {
            await api('/api/users', { method: 'POST', body: data });
          }
          toast('تم الحفظ'); done();
        }
      });
    }
    load();
  };

  // ---- settings
  pages.settings = async function () {
    if (!can('settings.manage')) return (location.hash = '#/dashboard');
    setTitle('الإعدادات', 'بيانات الشركة والضرائب والخيارات');
    const s = await api('/api/settings');
    const c = s.company;
    $('#view').innerHTML = '<div class="grid grid-2">' +
      '<div class="card"><div class="card-head"><h2>بيانات الشركة</h2></div><div class="card-body">' +
        '<label class="field"><span>اسم الشركة</span><input id="s-name" value="' + esc(c.name) + '"></label>' +
        '<label class="field"><span>الشكل القانوني</span><input id="s-legal" value="' + esc(c.legalForm) + '"></label>' +
        '<label class="field"><span>رأس المال</span><input id="s-capital" value="' + esc(c.capital) + '"></label>' +
        '<label class="field"><span>العنوان</span><input id="s-address" value="' + esc(c.address) + '"></label>' +
        '<div class="form-grid"><label class="field"><span>المعرف الجبائي</span><input id="s-tax" value="' + esc(c.taxId) + '"></label>' +
        '<label class="field"><span>السجل التجاري</span><input id="s-rc" value="' + esc(c.rc) + '"></label></div>' +
        '<div class="form-grid"><label class="field"><span>الهاتف</span><input id="s-phone" value="' + esc(c.phone) + '"></label>' +
        '<label class="field"><span>البريد</span><input id="s-email" value="' + esc(c.email) + '"></label></div>' +
      '</div></div>' +
      '<div class="card"><div class="card-head"><h2>الضرائب والمخزون</h2></div><div class="card-body">' +
        '<label class="field"><span>الطابع الجبائي (د.ت)</span><input type="number" step="0.001" id="s-stamp" value="' + esc(s.stamp) + '"></label>' +
        '<label class="field"><span>حد التنبيه للمخزون</span><input type="number" step="1" id="s-low" value="' + esc(s.lowStockThreshold) + '"></label>' +
        '<label class="field"><span>بادئة الفواتير</span><input id="s-invprefix" value="' + esc(s.invoicePrefix) + '"></label>' +
        '<label class="field"><span>بادئة الوصولات</span><input id="s-bonprefix" value="' + esc(s.billPrefix) + '"></label>' +
        '<label class="switch" style="margin:14px 0"><input type="checkbox" id="s-neg" ' + (s.allowNegativeStock ? 'checked' : '') + '> السماح بالبيع بمخزون سالب</label>' +
        '<button class="btn btn-primary btn-block" id="s-save">' + icon('i-check') + ' حفظ الإعدادات</button>' +
        '<hr style="border:0;border-top:1px solid var(--line);margin:22px 0">' +
        '<h3 style="font-size:14px;margin-bottom:6px">النسخ الاحتياطي</h3>' +
        '<p class="muted" style="font-size:12.5px;margin-bottom:12px">تنزيل نسخة كاملة من قاعدة البيانات بصيغة JSON.</p>' +
        '<button class="btn btn-soft btn-block" id="s-backup">' + icon('i-download') + ' تنزيل نسخة احتياطية</button>' +
      '</div></div></div>';

    $('#s-save').addEventListener('click', async function () {
      this.disabled = true;
      try {
        await api('/api/settings', {
          method: 'PUT', body: {
            company: {
              name: $('#s-name').value, legalForm: $('#s-legal').value, capital: $('#s-capital').value,
              address: $('#s-address').value, taxId: $('#s-tax').value, rc: $('#s-rc').value,
              phone: $('#s-phone').value, email: $('#s-email').value
            },
            stamp: Number($('#s-stamp').value), lowStockThreshold: Number($('#s-low').value),
            invoicePrefix: $('#s-invprefix').value, billPrefix: $('#s-bonprefix').value,
            allowNegativeStock: $('#s-neg').checked
          }
        });
        toast('تم حفظ الإعدادات');
        state.meta = await api('/api/meta');
      } catch (e) { toast(e.message, 'error'); }
      this.disabled = false;
    });
    $('#s-backup').addEventListener('click', async function () {
      try {
        const data = await api('/api/backup');
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'bhb-backup-' + todayStr() + '.json';
        a.click();
        URL.revokeObjectURL(a.href);
        toast('تم تنزيل النسخة الاحتياطية');
      } catch (e) { toast(e.message, 'error'); }
    });
  };

  // ---- audit
  pages.audit = async function () {
    if (!can('audit.read')) return (location.hash = '#/dashboard');
    setTitle('سجل التدقيق', 'كل العمليات الحساسة ومن قام بها');
    let query = { page: 1, q: '' };
    const view = $('#view');
    async function load() {
      const res = await api('/api/audit?page=' + query.page + '&pageSize=20&q=' + encodeURIComponent(query.q));
      const labels = {
        'login': 'دخول', 'logout': 'خروج', 'invoice.create': 'إنشاء فاتورة', 'invoice.update': 'تعديل فاتورة',
        'invoice.pay': 'تحصيل فاتورة', 'invoice.cancel': 'إلغاء فاتورة', 'bill.create': 'إنشاء وصل',
        'bill.pay': 'تحصيل وصل', 'bill.convert': 'تحويل وصل', 'bill.cancel': 'إلغاء وصل',
        'product.create': 'إضافة مادة', 'product.update': 'تعديل مادة', 'product.delete': 'حذف مادة',
        'client.create': 'إضافة حريف', 'client.update': 'تعديل حريف', 'client.delete': 'حذف حريف',
        'supplier.create': 'إضافة مزود', 'supplier.update': 'تعديل مزود', 'supplier.delete': 'حذف مزود',
        'purchase.create': 'شراء', 'purchase.update': 'تعديل شراء', 'purchase.delete': 'حذف شراء',
        'user.create': 'إضافة مستخدم', 'user.update': 'تعديل مستخدم', 'user.delete': 'حذف مستخدم',
        'settings.update': 'تعديل إعدادات', 'password.change': 'تغيير كلمة سر', 'backup.export': 'نسخ احتياطي'
      };
      view.innerHTML = '<div class="toolbar"><div class="search">' + icon('i-search') + '<input id="a-q" placeholder="بحث في السجل…" value="' + esc(query.q) + '"></div></div>' +
        '<div class="card"><div class="table-wrap"><table class="data"><thead><tr><th>التاريخ</th><th>المستخدم</th><th>العملية</th><th>التفاصيل</th></tr></thead><tbody>' +
        (res.items.map(function (a) {
          const d = new Date(a.at);
          return '<tr><td class="t-sub">' + d.toLocaleDateString('fr-TN') + ' ' + d.toLocaleTimeString('fr-TN', { hour: '2-digit', minute: '2-digit' }) + '</td>' +
            '<td class="t-name">' + esc(a.username) + '</td><td><span class="badge blue">' + esc(labels[a.action] || a.action) + '</span></td>' +
            '<td class="t-sub">' + esc(a.details || '') + '</td></tr>';
        }).join('') || '<tr><td colspan="4"><div class="empty">لا توجد عمليات</div></td></tr>') +
        '</tbody></table></div>' + pager(res) + '</div>';
      $('#a-q').addEventListener('input', debounce(function (e) { query.q = e.target.value; query.page = 1; load(); }, 300));
      bindPager(view, (p) => { query.page = p; load(); });
    }
    load();
  };

  // ---- database (superuser: import bhf22.sql)
  pages.database = async function () {
    if (!can('system.import')) return (location.hash = '#/dashboard');
    setTitle('قاعدة البيانات', 'استيراد قاعدة البيانات القديمة ومراقبة المحتوى');
    const view = $('#view');
    let timer = null;

    const LABELS = [
      ['clients', 'الحرفاء'], ['suppliers', 'المزودون'], ['products', 'المواد'],
      ['invoices', 'الفواتير'], ['invoice_lines', 'أسطر الفواتير'],
      ['bills', 'الوصولات'], ['bill_lines', 'أسطر الوصولات'],
      ['purchases', 'الشراءات'], ['payments', 'الدفعات'],
      ['users', 'المستخدمون'], ['audit', 'سجل التدقيق']
    ];
    const kb = (b) => !b ? '—' : (b >= 1048576 ? (b / 1048576).toFixed(1) + ' م.ب' : Math.round(b / 1024) + ' ك.ب');

    async function load() {
      const info = await api('/api/admin/db-info');
      const total = LABELS.reduce(function (s, l) { return s + (info.counts[l[0]] || 0); }, 0);
      view.innerHTML =
        '<div class="stat-row">' +
          '<div class="stat"><span>إجمالي السجلات</span><strong>' + num(total, 0) + '</strong></div>' +
          '<div class="stat"><span>الفواتير</span><strong>' + num(info.counts.invoices, 0) + '</strong></div>' +
          '<div class="stat"><span>أسطر الفواتير</span><strong>' + num(info.counts.invoice_lines, 0) + '</strong></div>' +
          '<div class="stat"><span>الفترة</span><strong style="font-size:15px">' + (info.period.from ? dt(info.period.from) + ' → ' + dt(info.period.to) : '—') + '</strong></div>' +
        '</div>' +
        '<div class="grid grid-2">' +
          '<div class="card"><div class="card-head"><h2>محتوى قاعدة البيانات الحالية</h2><div class="spacer"></div>' +
            '<span class="badge blue">' + esc(info.storage.file || 'db.json') + ' · ' + kb(info.storage.bytes) + '</span></div>' +
            '<div class="table-wrap"><table class="data"><thead><tr><th>الجدول</th><th>عدد السجلات</th></tr></thead><tbody>' +
            LABELS.map(function (l) {
              return '<tr><td>' + l[1] + '</td><td class="num">' + num(info.counts[l[0]] || 0, 0) + '</td></tr>';
            }).join('') +
            '</tbody></table></div></div>' +
          '<div class="card"><div class="card-head"><h2>استيراد قاعدة بيانات</h2></div><div class="card-body">' +
            '<div class="alert" style="background:var(--amber-bg);color:#8a5a12;border-color:#efdcbb">' +
              'سيتم <b>استبدال</b> الحرفاء والمزودين والمواد والفواتير والوصولات والشراءات بالبيانات الواردة في الملف. ' +
              'يبقى المستخدمون وسجل التدقيق كما هما. ننصح بتنزيل نسخة احتياطية أولاً.' +
            '</div>' +
            '<button class="btn btn-soft btn-block" id="db-backup">' + icon('i-download') + ' تنزيل نسخة احتياطية الآن</button>' +
            '<hr style="border:0;border-top:1px solid var(--line);margin:20px 0">' +
            (info.bundled
              ? '<div class="field"><span>الملف المرفق في المشروع</span>' +
                '<div style="display:flex;align-items:center;gap:10px;background:var(--mint-2);border:1px solid var(--line);border-radius:10px;padding:12px 14px">' +
                icon('i-db') + '<div><div class="t-name">' + esc(info.bundled.name) + '</div>' +
                '<div class="t-sub">' + kb(info.bundled.bytes) + ' · ' + dt(info.bundled.modified.slice(0, 10)) + '</div></div></div></div>' +
                '<button class="btn btn-primary btn-block" id="db-bundled">' + icon('i-db') + ' استيراد قاعدة البيانات (' + esc(info.bundled.name) + ')</button>'
              : '<div class="alert">لم يتم العثور على ملف قاعدة بيانات مرفق (.sql). يمكنك رفع الملف يدوياً أدناه.</div>') +
            '<hr style="border:0;border-top:1px solid var(--line);margin:20px 0">' +
            '<label class="field"><span>أو ارفع ملف تفريغ MySQL آخر (.sql)</span>' +
              '<input type="file" id="db-file" accept=".sql,text/plain"></label>' +
            '<button class="btn btn-ghost btn-block" id="db-upload">' + icon('i-plus') + ' استيراد الملف المرفوع</button>' +
            '<div id="db-progress" style="margin-top:14px"></div>' +
            (info.lastImport
              ? '<div class="t-sub" style="margin-top:16px">آخر استيراد: ' + esc(info.lastImport.username) + ' — ' +
                new Date(info.lastImport.at).toLocaleString('fr-TN') + '<br>' + esc(info.lastImport.details || '') + '</div>'
              : '') +
          '</div></div>' +
        '</div>';

      const progress = function (msg, spin) {
        $('#db-progress').innerHTML = '<div class="alert ok" style="display:flex;gap:10px;align-items:center">' +
          (spin ? '<span class="dot" style="width:10px;height:10px;background:var(--teal);animation:none"></span>' : '') +
          '<span>' + esc(msg) + '</span></div>';
      };

      const runImport = async function (mode) {
        const ok = await confirmDialog('تأكيد استيراد قاعدة البيانات',
          'سيتم استبدال بيانات الحرفاء والمواد والفواتير والوصولات والشراءات نهائياً. ' +
          'تأكد من تنزيل نسخة احتياطية قبل المتابعة. هل تريد المتابعة؟', 'نعم، استيراد');
        if (!ok) return;

        let started = Date.now();
        let elapsed = 0;
        progress('جارٍ قراءة الملف وتحليل ' + (mode === 'bundled' ? 'bhf22.sql' : 'الملف المرفوع') + '…', true);
        if (timer) clearInterval(timer);
        timer = setInterval(function () {
          elapsed = Math.round((Date.now() - started) / 1000);
          progress('جارٍ الاستيراد… ' + elapsed + ' ثانية (قد يستغرق حتى دقيقة)', true);
        }, 1000);

        try {
          let result;
          if (mode === 'bundled') {
            result = await api('/api/admin/import-sql', { method: 'POST', body: { source: 'bundled' } });
          } else {
            const input = $('#db-file');
            const file = input.files && input.files[0];
            if (!file) throw new Error('اختر ملف .sql أولاً');
            if (file.size > 150 * 1024 * 1024) throw new Error('حجم الملف يتجاوز 150 ميغابايت');
            const text = await file.text();
            progress('تم تحميل ' + kb(file.size) + ' — جارٍ الاستيراد…', true);
            const res = await fetch('/api/admin/import-sql', {
              method: 'POST',
              credentials: 'same-origin',
              headers: { 'Content-Type': 'text/plain; charset=utf-8', 'X-CSRF-Token': state.csrf },
              body: text
            });
            const data = await res.json().catch(function () { return null; });
            if (!res.ok) throw new Error((data && data.error) || 'فشل الاستيراد (' + res.status + ')');
            result = data;
          }
          clearInterval(timer); timer = null;
          const i = result.imported;
          progress('تم الاستيراد بنجاح في ' + (result.durationMs / 1000).toFixed(1) + ' ثانية', false);
          openModal({
            title: 'نتيجة الاستيراد',
            body: '<div class="stat-row" style="margin-bottom:6px">' +
                '<div class="stat"><span>حرفاء</span><strong>' + num(i.clients, 0) + '</strong></div>' +
                '<div class="stat"><span>مواد</span><strong>' + num(i.products, 0) + '</strong></div>' +
                '<div class="stat"><span>فواتير</span><strong>' + num(i.invoices, 0) + '</strong></div>' +
                '<div class="stat"><span>أسطر</span><strong>' + num(i.invoice_lines, 0) + '</strong></div>' +
                '<div class="stat"><span>وصولات</span><strong>' + num(i.bills, 0) + '</strong></div>' +
                '<div class="stat"><span>شراءات</span><strong>' + num(i.purchases, 0) + '</strong></div>' +
              '</div>' +
              (result.warnings && result.warnings.length
                ? '<div class="alert" style="margin-top:12px"><b>تنبيهات (' + result.warningCount + '):</b><br>' + result.warnings.map(esc).join('<br>') + '</div>'
                : '<div class="alert ok">لا توجد تنبيهات.</div>'),
            footer: '<button class="btn btn-primary" data-close>تم</button>'
          });
          state.meta = await api('/api/meta');
          await load();
        } catch (err) {
          if (timer) { clearInterval(timer); timer = null; }
          progress('فشل الاستيراد: ' + err.message, false);
          toast(err.message, 'error');
        }
      };

      $('#db-backup').addEventListener('click', async function () {
        try {
          const data = await api('/api/backup');
          const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
          const a = document.createElement('a');
          a.href = URL.createObjectURL(blob);
          a.download = 'bhb-backup-' + todayStr() + '.json';
          a.click();
          URL.revokeObjectURL(a.href);
          toast('تم تنزيل النسخة الاحتياطية');
        } catch (e) { toast(e.message, 'error'); }
      });
      if ($('#db-bundled')) $('#db-bundled').addEventListener('click', function () { runImport('bundled'); });
      $('#db-upload').addEventListener('click', function () { runImport('upload'); });
    }

    await load();
  };

  // ---------------------------------------------------------------- printing
  function companyHeader() {
    const c = state.meta.company;
    return '<div class="print-co"><h2>' + esc(c.name) + '</h2>' +
      '<div>' + esc(c.legalForm) + ' — ' + esc(c.tagline) + '<br>' +
      'رأس المال: ' + esc(c.capital) + '<br>' +
      esc(c.address) + '<br>' +
      'المعرف الجبائي: ' + esc(c.taxId) + ' — السجل التجاري: ' + esc(c.rc) + '<br>' +
      'الهاتف: ' + esc(c.phone) + (c.email ? ' — ' + esc(c.email) : '') + '</div></div>';
  }

  function printInvoice(inv, mode) {
    const c = inv.client || {};
    const accountant = mode === 'accountant';
    const lines = inv.lines.map(function (l, i) {
      if (accountant) {
        return '<tr><td>' + (i + 1) + '</td><td>' + esc(l.name) + '</td><td>' + num(l.qty, 0) + '</td><td>' + num(l.unitHt) + '</td>' +
          '<td>' + num(l.ht) + '</td><td>' + num(l.discount) + '</td><td>' + num(l.vatRate, 0) + '%</td><td>' + num(l.vat) + '</td><td>' + num(l.ttc) + '</td></tr>';
      }
      return '<tr><td>' + (i + 1) + '</td><td>' + esc(l.name) + '</td><td>' + num(l.qty, 0) + '</td>' +
        '<td>' + num(l.unitHt * (1 + l.vatRate / 100)) + '</td><td>' + num(l.ht - l.discount + l.vat) + '</td></tr>';
    }).join('');

    const head = accountant
      ? '<tr><th>#</th><th>الوصف</th><th>الكمية</th><th>السعر خ.أ</th><th>المجموع خ.أ</th><th>التخفيض</th><th>أ.ق.م</th><th>مبلغ الأداء</th><th>الجملة</th></tr>'
      : '<tr><th>#</th><th>الوصف</th><th>الكمية</th><th>السعر الفردي</th><th>الثمن</th></tr>';

    const totals = accountant
      ? '<tr><td>المجموع خ.أ</td><td>' + num(inv.ht) + '</td></tr><tr><td>التخفيض</td><td>' + num(inv.discount) + '</td></tr>' +
        '<tr><td>الأداء على القيمة المضافة</td><td>' + num(inv.vat) + '</td></tr>' +
        '<tr><td>الطابع الجبائي</td><td>' + num(inv.stamp) + '</td></tr>' +
        '<tr class="grand"><td>الجملة</td><td>' + num(inv.total) + ' د.ت</td></tr>'
      : '<tr><td>التخفيض</td><td>' + num(inv.discount) + '</td></tr>' +
        '<tr><td>الطابع الجبائي</td><td>' + num(inv.stamp) + '</td></tr>' +
        '<tr class="grand"><td>الجملة</td><td>' + num(inv.total) + ' د.ت</td></tr>';

    const clientBlock = '<div class="print-client"><h3>بيانات الحريف</h3>' +
      '<strong>' + esc(c.name || inv.clientName || 'حريف عابر') + '</strong>' +
      (c.address ? '<div>' + esc(c.address) + '</div>' : '') +
      (c.taxId ? '<div>المعرف الجبائي: ' + esc(c.taxId) + '</div>' : '') +
      (c.rc ? '<div>السجل التجاري: ' + esc(c.rc) + '</div>' : '') +
      (c.phone ? '<div>الهاتف: ' + esc(c.phone) + '</div>' : '') +
      '</div>';

    const invoiceBlock = '<div class="print-title print-doc-info"><h1>' + (accountant ? 'فاتورة (نسخة المحاسب)' : 'فاتورة') + '</h1>' +
      '<div class="meta">عدد الفاتورة: <b>' + esc(inv.number) + '</b><br>تاريخ الفاتورة: ' + dt(inv.date) + '<br>الحالة: ' + (inv.status === 'paid' ? 'خالصة' : inv.status === 'cancelled' ? 'ملغاة' : 'غير خالصة') + '</div></div>';

    $('#print-root').innerHTML = '<div class="print-doc">' +
      '<div class="print-body-content">' +
        '<div class="print-head print-head-3col">' +
          companyHeader() +
          invoiceBlock +
          clientBlock +
        '</div>' +
        '<table class="print"><thead>' + head + '</thead><tbody>' + lines + '</tbody></table>' +
        '<div class="print-totals"><table>' + totals + '</table></div>' +
      '</div>' +
      '<div class="print-footer-pinned">' +
        '<div class="print-foot"><span></span><span>توقيع وختم الشركة</span></div>' +
        '<div class="print-legal">' + esc(state.meta.company.name) + ' — ' + esc(state.meta.company.address) + '<br>' +
        'وثيقة صادرة إلكترونياً — ' + new Date().toLocaleString('fr-TN') + '</div>' +
      '</div>' +
    '</div>';
    window.print();
    setTimeout(() => { $('#print-root').innerHTML = ''; }, 600);
  }

  function printBill(b) {
    const c = b.client || {};
    $('#print-root').innerHTML = '<div class="print-doc">' +
      '<div class="print-head">' + companyHeader() +
        '<div class="print-title"><h1>وصل بيع</h1><div class="meta">رقم: <b>' + esc(b.number) + '</b><br>التاريخ: ' + dt(b.date) + '</div></div></div>' +
      '<div class="print-party"><div class="box"><b>الحريف</b>' + esc(c.name || b.clientName) + '<br>' + esc(c.address || '') + '</div>' +
      '<div class="box"><b>الحالة</b>' + (b.status === 'paid' ? 'خالص' : b.status === 'converted' ? 'محوّل إلى فاتورة' : b.status === 'cancelled' ? 'ملغى' : 'غير خالص') + '</div></div>' +
      '<table class="print"><thead><tr><th>#</th><th>الوصف</th><th>الكمية</th><th>السعر</th><th>المجموع</th></tr></thead><tbody>' +
      b.lines.map((l, i) => '<tr><td>' + (i + 1) + '</td><td>' + esc(l.name) + '</td><td>' + num(l.qty, 0) + '</td><td>' + num(l.unitTtc) + '</td><td>' + num(l.total) + '</td></tr>').join('') +
      '</tbody></table>' +
      '<div class="print-totals"><table><tr class="grand"><td>الجملة</td><td>' + num(b.total) + ' د.ت</td></tr></table></div>' +
      '<div class="print-foot"><span>المبلغ كتابةً: ' + esc(numberToArabic(b.total)) + '</span><span>التوقيع</span></div>' +
      '<div class="print-legal">' + esc(state.meta.company.name) + ' — ' + new Date().toLocaleString('fr-TN') + '</div>' +
    '</div>';
    window.print();
    setTimeout(() => { $('#print-root').innerHTML = ''; }, 600);
  }

  function numberToArabic(n) {
    const units = ['', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة', 'عشرة', 'أحد عشر', 'اثنا عشر',
      'ثلاثة عشر', 'أربعة عشر', 'خمسة عشر', 'ستة عشر', 'سبعة عشر', 'ثمانية عشر', 'تسعة عشر'];
    const tens = ['', '', 'عشرون', 'ثلاثون', 'أربعون', 'خمسون', 'ستون', 'سبعون', 'ثمانون', 'تسعون'];
    const hundreds = ['', 'مائة', 'مائتان', 'ثلاثمائة', 'أربعمائة', 'خمسمائة', 'ستمائة', 'سبعمائة', 'ثمانمائة', 'تسعمائة'];
    const int = Math.floor(Math.abs(Number(n) || 0));
    const parts = [];
    if (int >= 1000) { parts.push((int >= 2000 ? numberToArabic(Math.floor(int / 1000)) + ' آلاف' : 'ألف')); }
    let rem = int % 1000;
    if (rem >= 100) { parts.push(hundreds[Math.floor(rem / 100)]); rem = rem % 100; }
    if (rem > 0) {
      if (rem < 20) parts.push(units[rem]);
      else {
        const t = Math.floor(rem / 10), u = rem % 10;
        parts.push((u ? units[u] + ' و' : '') + tens[t]);
      }
    }
    if (!parts.length) parts.push('صفر');
    return parts.join(' و') + ' ديناراً';
  }

  // ---------------------------------------------------------------- utils
  function debounce(fn, ms) {
    let t;
    return function () {
      clearTimeout(t);
      const args = arguments;
      const el = args[0] && args[0].target;
      t = setTimeout(function () {
        Promise.resolve(fn.apply(null, args)).then(function () {
          // keep the caret inside the search field after the list re-renders
          if (el && el.id) {
            const again = document.getElementById(el.id);
            if (again) {
              again.focus();
              try { again.setSelectionRange(again.value.length, again.value.length); } catch (e) { /* non-text input */ }
            }
          }
        }).catch(function () { /* handled by page */ });
      }, ms);
    };
  }

  // ---------------------------------------------------------------- boot
  async function boot() {
    try {
      const me = await api('/api/auth/me');
      state.user = me.user; state.permissions = me.permissions; state.csrf = me.csrfToken;
      state.meta = await api('/api/meta');
      showApp();
      navigate();
    } catch (e) {
      showLogin();
      try { state.meta = await fetch('/api/meta').then((r) => r.json()); } catch (e2) { /* ignore */ }
    }

    $('#login-form').addEventListener('submit', async function (e) {
      e.preventDefault();
      const alertBox = $('#login-alert');
      const btn = $('#login-submit');
      alertBox.hidden = true; btn.disabled = true;
      try {
        const res = await api('/api/auth/login', { method: 'POST', body: { username: $('#login-user').value, password: $('#login-pass').value } });
        state.user = res.user; state.csrf = res.csrfToken;
        state.permissions = (await api('/api/auth/me')).permissions;
        state.meta = await api('/api/meta');
        showApp();
        location.hash = '#/dashboard';
        navigate();
        toast('مرحباً ' + res.user.name);
      } catch (err) {
        alertBox.textContent = err.message;
        alertBox.hidden = false;
      }
      btn.disabled = false;
    });

    $('#toggle-pass').addEventListener('click', function () {
      const p = $('#login-pass');
      p.type = p.type === 'password' ? 'text' : 'password';
    });

    $('#logout-btn').addEventListener('click', async function () {
      try { await api('/api/auth/logout', { method: 'POST', body: {} }); } catch (e) { /* ignore */ }
      state.csrf = null;
      showLogin();
    });

    $('#menu-btn').addEventListener('click', () => { $('#sidebar').classList.toggle('open'); $('#scrim').classList.toggle('show'); });
    $('#scrim').addEventListener('click', () => { $('#sidebar').classList.remove('open'); $('#scrim').classList.remove('show'); });
    $('#refresh-btn').addEventListener('click', () => navigate());
    window.addEventListener('hashchange', navigate);
  }

  // wrap navigate to handle detail routes
  const originalNavigate = navigate;
  navigate = function () {
    const parts = location.hash.replace(/^#\/?/, '').split('/');
    if (state.user) {
      if (parts[0] === 'invoices' && parts[1] === 'new') { setTitle('فاتورة جديدة', 'إنشاء فاتورة بيع'); invoiceEditor(null); return; }
      if (parts[0] === 'invoices' && parts[1] && parts[2] === 'edit') { invoiceEditor(parts[1]); return; }
      if (parts[0] === 'invoices' && parts[1]) { invoiceDetail(parts[1]); return; }
      if (parts[0] === 'bills' && parts[1] === 'new') { billEditor(); return; }
    }
    originalNavigate();
  };

  boot();
})();
